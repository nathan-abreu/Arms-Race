"""Loop, dispositivos e troca de cenas. Regras pertencem aos respectivos modulos."""
import pygame
from scripts.config import WIDTH, HEIGHT, FPS, FIXED_DT
from scripts.settings import Settings
from scripts.viewport import Viewport
from scripts.audio.manager import AudioManager


class Game:
    def __init__(self,initial_scene="menu",audio_enabled=True,developer=False):
        from scripts.ui.style import font
        font.cache_clear()
        pygame.display.init()
        pygame.font.init()
        self.settings=Settings()
        self.window=pygame.display.set_mode((WIDTH,HEIGHT),pygame.RESIZABLE)
        self.screen=pygame.Surface((WIDTH,HEIGHT)).convert()
        self.viewport=Viewport((WIDTH,HEIGHT))
        pygame.display.set_caption("ARMS RACE - Ringue Neon")
        self.clock=pygame.time.Clock()
        self.audio=AudioManager(self.settings,audio_enabled)
        self.running=True
        self.scene=None
        self.intro_seen=False
        self.debug=False
        from scripts.development import DeveloperPlayback
        self.development=DeveloperPlayback(developer)
        self.accumulator=0.0
        self.arena_art=None
        if initial_scene=="ringue": self.start_match()
        else: self.show_menu()

    def change_scene(self,scene):
        self.scene=scene

    def show_menu(self):
        from scripts.scenes.menu import Menu
        self.change_scene(Menu(self))
        self.audio.set_music("menu")

    def start_match(self):
        from scripts.scenes.ringue_neon import RingueNeon
        self.change_scene(RingueNeon(self))
        self.audio.set_music("ringue")

    def apply_display(self):
        flags=pygame.FULLSCREEN if self.settings.fullscreen else pygame.RESIZABLE
        try:
            self.window=pygame.display.set_mode(self.settings.resolution,flags)
        except pygame.error:
            self.settings.fullscreen=False
            self.settings.resolution=(1280,720)
            self.window=pygame.display.set_mode((1280,720),pygame.RESIZABLE)
        self.viewport.resize(self.window.get_size())

    def process_event(self,event):
        from scripts.scenes.ringue_neon import RingueNeon
        from scripts.scenes.pausa import Pausa
        if self.development.handle(event,self):return
        if event.type==pygame.QUIT: self.running=False
        elif event.type==pygame.VIDEORESIZE and not self.settings.fullscreen:
            self.settings.resolution=(max(640,event.w),max(360,event.h))
            self.apply_display()
        elif event.type==pygame.KEYDOWN and event.key==pygame.K_F3:
            self.debug=not self.debug
        elif event.type==pygame.WINDOWFOCUSLOST:
            if isinstance(self.scene,RingueNeon) and not self.scene.result:
                self.scene.player.release_jump()
                self.change_scene(Pausa(self,self.scene))
                self.audio.play("pause")
        else:
            if event.type==pygame.KEYDOWN and not isinstance(self.scene,RingueNeon):
                sound="confirm" if event.key in (pygame.K_RETURN,pygame.K_KP_ENTER) else "back" if event.key==pygame.K_ESCAPE else "select"
                self.audio.play(sound,variation=False)
            self.scene.handle_event(event)

    def advance(self,elapsed):
        """Relógio único de 120 Hz: slow motion e passo atuam na simulação."""
        dev=self.development
        if dev.enabled and dev.paused:
            if dev.step_requested:
                self.scene.update(FIXED_DT)
                dev.step_requested=False
            self.scene.render_alpha=1.0
            return
        self.accumulator+=min(elapsed,.1)*(dev.speed if dev.enabled else 1)
        while self.accumulator+1e-10>=FIXED_DT:
            self.scene.update(FIXED_DT)
            self.accumulator=max(0,self.accumulator-FIXED_DT)
        self.scene.render_alpha=max(0,min(1,self.accumulator/FIXED_DT))

    def run(self,max_frames=0):
        frames=0
        try:
            while self.running:
                # Temporização mais precisa evita intervalos irregulares do
                # sleep do Windows. A simulação continua usando passo fixo.
                elapsed=min(self.clock.tick_busy_loop(FPS)/1000,.1)
                self.development.frame_ms=elapsed*1000
                for event in pygame.event.get(): self.process_event(event)
                if not self.running: break
                self.audio.update(elapsed)
                self.advance(elapsed)
                self.scene.draw(self.screen)
                self.development.draw(self.screen,self.clock.get_fps())
                self.viewport.present(self.screen,self.window)
                pygame.display.flip()
                frames+=1
                if max_frames and frames>=max_frames: self.running=False
        finally:
            self.audio.stop()
            from scripts.ui.style import font
            font.cache_clear()
            pygame.quit()

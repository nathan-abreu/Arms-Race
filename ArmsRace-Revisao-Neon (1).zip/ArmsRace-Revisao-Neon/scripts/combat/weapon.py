from dataclasses import dataclass
from collections import deque
import math
import pygame
from scripts.config import GOLD, GRAVITY
from scripts.ui.style import text
from scripts.balance import DELIVERY


def pan_support(angle):
    """Suporte do bojo/cabo ao girar, relativo ao pivô central, em pixels."""
    a=math.radians(angle)
    body=math.hypot(24*math.sin(a),14*math.cos(a))+2
    handle=-42*math.sin(a)+8*math.cos(a)+3
    return max(18.0,body,handle)


@dataclass(frozen=True)
class Weapon:
    name: str
    damage: int
    reach: int
    knockback: float
    cooldown: float
    duration: float
    icon: str = "panela"
    preview_only: bool = False
    ammo: int | None = None


FISTS = Weapon("Soco", 7, 52, 255, .32, .12,"soco")
PAN = Weapon("Panela", 10, 56, 390, .38, .12)
PREVIEW_WEAPONS=(Weapon("Machado",0,0,0,.4,.1,"machado",True),
                 Weapon("Rifle",0,0,0,.4,.1,"rifle",True,30),
                 Weapon("Lançador",0,0,0,.4,.1,"lancador",True,3))


class Inventory:
    def __init__(self):
        self.slots = [None, None, None]
        self.selected = 0
        self.changes=deque(maxlen=16)
        self.preview=None

    @property
    def display_slots(self):
        return self.preview if self.preview is not None else self.slots

    def toggle_preview(self):
        self.preview=None if self.preview is not None else list(PREVIEW_WEAPONS)
        self.changes.append(('cycle',self.selected,None))

    @property
    def weapon(self):
        return self.slots[self.selected] or FISTS

    @property
    def full(self):
        return all(slot is not None for slot in self.slots)

    def cycle(self, direction):
        self.selected = (self.selected + direction) % len(self.slots)
        self.changes.append(('cycle',self.selected,self.display_slots[self.selected]))

    def collect(self, weapon):
        if self.full or weapon.preview_only:
            return False
        index = self.selected if self.slots[self.selected] is None else self.slots.index(None)
        self.slots[index] = weapon
        self.selected = index
        self.changes.append(('collect',index,weapon))
        return True

    def discard(self):
        weapon = self.slots[self.selected]
        self.slots[self.selected] = None
        if weapon: self.changes.append(('discard',self.selected,weapon))
        return weapon


class WeaponDrop:
    """Entrega única, com perigo sinalizado e impacto antes da coleta."""
    def __init__(self, level, rng):
        self.level, self.rng = level, rng
        self.state = "waiting"
        self.timer = level["weapon_interval"]
        self.x, self.y, self.vy = 640.0, -40.0, 0.0
        self.portal_y=DELIVERY.origin_y
        self.previous=(self.x,self.y,0.0)
        self.effect_age=0.0
        self.floor_y = level["platforms"][0][1]
        self.lock_owner = None
        self.lock_time = self.pickup_delay = 0.0
        self.sky_drop = True
        self.hit_targets = set()
        self.impact_event = None
        self.damage_events = []
        self.angle = 0.0
        self.trail = []
        self.beam_fade=0.0
        self.impact_age=1.0
        self.collection=None
        self.collection_angle=0.0
        self.rest_floor=None
        self.landing_angle=0.0
        self.previous_visual=(self.timer,self.effect_age,self.beam_fade,self.impact_age,self.state)
        from scripts.effects.delivery import DeliveryArt
        self.art=DeliveryArt(self.floor_y)

    def update(self, dt, fighters, platforms):
        self.previous=(self.x,self.y,self.angle)
        self.previous_visual=(self.timer,self.effect_age,self.beam_fade,self.impact_age,self.state)
        if self.state in ('warning','opening','falling') or self.beam_fade>0:
            self.effect_age+=dt
        self.impact_event = None
        self.damage_events.clear()
        self.beam_fade=max(0,self.beam_fade-dt)
        self.impact_age+=dt
        if self.state=='available' and self.rest_floor is not None:
            u=min(1,self.impact_age/.18)
            u=u*u*(3-2*u)
            self.angle=self.landing_angle*(1-u)
            self.y=self.rest_floor-pan_support(self.angle)
        if self.collection:
            self.collection[2]+=dt
            if self.collection[2]>=DELIVERY.pickup_flight:
                self.collection[0].pickup_time=0
                self.collection=None
        self.lock_time = max(0, self.lock_time-dt)
        self.pickup_delay = max(0, self.pickup_delay-dt)
        if any(PAN in f.inventory.slots for f in fighters):
            self.state = "held"
            return
        if self.state == "held":
            self.state, self.timer = "waiting", self.level["weapon_interval"]
        if self.state in ("waiting", "warning", "opening"):
            self.timer -= dt
            if self.timer <= 0:
                if self.state == "waiting":
                    base = platforms[0]
                    safe = [x for x in self.level["weapon_drop_points"]
                            if base.left+90 < x < base.right-90 and
                            not any(p.left-35 < x < p.right+35 for p in platforms[1:])]
                    self.x = float(self.rng.choice(safe)) if safe else float(base.centerx)
                    self.state, self.timer = "warning", self.level["weapon_warning"]
                    self.y, self.vy, self.angle = self.portal_y, 0.0, 0.0
                    self.effect_age=0.0
                    self.previous=(self.x,self.y,self.angle)
                    self.hit_targets.clear()
                    self.trail.clear()
                    self.sky_drop = True
                    self.lock_owner = None
                elif self.state=='warning':
                    # A origem precisa estar vazia mesmo se alguém saltou
                    # durante o aviso. O ponto anunciado no piso não muda.
                    spawn=pygame.Rect(self.x-28,self.portal_y-25,56,50)
                    if not any(spawn.colliderect(f.rect) for f in fighters):
                        self.state,self.timer = "opening",DELIVERY.opening
                    else:
                        self.timer=.1
                else:
                    self.state='falling'
        if self.state == "falling":
            old_y = self.y
            old_angle=self.angle
            self.vy += (DELIVERY.acceleration if self.sky_drop else GRAVITY)*dt
            self.y += self.vy*dt
            self.angle += dt*(DELIVERY.spin_speed if self.sky_drop else 420)
            self.trail.append((self.x,self.y))
            self.trail = self.trail[-7:]
            if self.sky_drop and self.vy > 0:
                swept = pygame.Rect(self.x-25,old_y-14,50,max(28,self.y-old_y+28))
                for fighter in fighters:
                    if fighter not in self.hit_targets and swept.colliderect(fighter.rect):
                        self.hit_targets.add(fighter)
                        direction = 1 if fighter.pos.x >= self.x else -1
                        if fighter.receive_damage(8, 330, direction):
                            self.damage_events.append(fighter)
            for platform in sorted(platforms,key=lambda p:p.top):
                if platform.left <= self.x <= platform.right and old_y+pan_support(old_angle) <= platform.top+1 and self.y+pan_support(self.angle)>=platform.top:
                    # Resolve a fração do passo no contato: centro e rotação
                    # nunca são teleportados para corrigir o cabo no piso.
                    lo,hi=0.0,1.0
                    for _ in range(12):
                        u=(lo+hi)/2
                        bottom=old_y+(self.y-old_y)*u+pan_support(old_angle+(self.angle-old_angle)*u)
                        if bottom<platform.top:lo=u
                        else:hi=u
                    self.y=old_y+(self.y-old_y)*hi
                    self.angle=old_angle+(self.angle-old_angle)*hi
                    self.landing_angle=(self.angle+180)%360-180
                    self.angle=self.landing_angle
                    self.rest_floor=platform.top
                    self.vy=0
                    self.state = "available"
                    self.pickup_delay = .12 if self.sky_drop else 0
                    if self.sky_drop:
                        self.impact_event = (self.x,platform.top)
                        self.beam_fade=DELIVERY.dissolve
                        self.impact_age=0
                    self.trail.clear()
                    break
            if self.y > 780:
                self.state, self.timer = "waiting", self.level["weapon_interval"]

    def try_collect(self, fighter):
        if self.state != "available" or self.pickup_delay>0 or (fighter is self.lock_owner and self.lock_time>0):
            return False
        rect=pygame.Rect(self.x-28,self.y-20,56,40)
        if fighter.alive and fighter.rect.colliderect(rect) and fighter.inventory.collect(PAN):
            self.state="held"
            self.collection=[fighter,pygame.Vector2(self.x,self.y),0.0]
            self.collection_angle=self.angle
            fighter.pickup_time=DELIVERY.pickup_flight
            return True
        return False

    def discard(self, fighter):
        if fighter.inventory.preview is not None:
            index=fighter.inventory.selected
            weapon=fighter.inventory.preview[index]
            if weapon:
                fighter.inventory.preview[index]=None
                fighter.inventory.changes.append(('discard',index,weapon))
                fighter.events.append('discard')
            return weapon is not None
        weapon=fighter.inventory.discard()
        if weapon is None:
            return False
        self.collection=None
        fighter.pickup_time=0
        self.x,self.y=fighter.weapon_center
        self.angle=165-math.degrees(math.atan2(fighter.aim.y,fighter.aim.x))
        self.vy=-180
        self.previous=(self.x,self.y,self.angle)
        self.state="falling"
        self.rest_floor=None
        self.lock_owner,self.lock_time=fighter,1.0
        self.sky_drop=False
        self.trail.clear()
        self.hit_targets.clear()
        fighter.events.append('discard')
        return True

    def draw(self, surface, time, alpha=1):
        from copy import copy
        view=copy(self)
        px,py,pa=self.previous
        view.x=px+(self.x-px)*alpha
        view.y=py+(self.y-py)*alpha
        delta=(self.angle-pa+180)%360-180
        view.angle=pa+delta*alpha
        timer,age,fade,impact,state=self.previous_visual
        if state==self.state:
            view.timer=timer+(self.timer-timer)*alpha
            view.effect_age=age+(self.effect_age-age)*alpha
            view.beam_fade=fade+(self.beam_fade-fade)*alpha
            view.impact_age=impact+(self.impact_age-impact)*alpha
        self.art.draw(surface,view,time)

"""Controles de revisão visual, ativados explicitamente por --dev."""
import pygame
from scripts.ui.style import panel,text


class DeveloperPlayback:
    def __init__(self,enabled=False):
        self.enabled=enabled
        self.speed=1.0
        self.paused=False
        self.step_requested=False
        self.show_bones=True
        self.frame_ms=0.0

    def handle(self,event,game):
        if not self.enabled or event.type!=pygame.KEYDOWN:return False
        key=event.key
        if key==pygame.K_F5:
            speeds=(1.0,.5,.25)
            self.speed=speeds[(speeds.index(self.speed)+1)%3]
        elif key==pygame.K_F6:self.paused=not self.paused
        elif key==pygame.K_F7:self.paused=True;self.step_requested=True
        elif key==pygame.K_F9:game.start_match();game.scene.flow.phase='fight';game.accumulator=0
        elif key==pygame.K_F10:self.show_bones=not self.show_bones
        elif key==pygame.K_F8:
            from scripts.scenes.ringue_neon import RingueNeon
            if isinstance(game.scene,RingueNeon):
                game.scene.trigger_delivery()
        else:return False
        return True

    def draw(self,surface,fps):
        if not self.enabled:return
        panel(surface,(16,104,432,118),(255,220,80))
        lines=(f'DEV  {self.speed:.0%}  {"PAUSADO" if self.paused else "RODANDO"}  {fps:.1f} FPS / {self.frame_ms:.2f} ms',
               'F5 velocidade  F6 pausa  F7 passo 1/120 s',
               'F8 panela  F9 reiniciar  F10 ossos/pivos',
               'CPU parada para revisao visual; combate preservado.')
        for i,line in enumerate(lines):text(surface,line,(27,115+i*24),20)

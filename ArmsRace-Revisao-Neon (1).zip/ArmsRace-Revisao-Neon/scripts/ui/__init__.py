"""Elementos visuais compartilhados."""

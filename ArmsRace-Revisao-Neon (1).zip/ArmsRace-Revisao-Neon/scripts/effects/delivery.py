"""Feixe em camadas, marcador segmentado e Panela original filtrada."""
import math
import pygame
from scripts.effects.pan_art import pan,GOLD
from scripts.effects.neon import halo
from scripts.balance import DELIVERY


def ease(u):
    u=max(0,min(1,u));return u*u*(3-2*u)


class DeliveryArt:
    def __init__(self,floor):
        self.floor=floor
        self.beam=pygame.Surface((220,floor+32),pygame.SRCALPHA)
        for column in range(220):
            distance=abs(column-110)
            opacity=round(85*math.exp(-(distance/18)**2)+28*math.exp(-(distance/45)**2))
            pygame.draw.line(self.beam,(*GOLD,opacity),(column,0),(column,floor))
        pygame.draw.line(self.beam,(255,242,158,235),(110,0),(110,floor),3)
        self.beams=(self.beam,)
        self.width=220
        self.lines=pygame.Surface((220,floor+32),pygame.SRCALPHA)
        self.floor_light=pygame.transform.smoothscale(halo(GOLD,100),(200,36))
        self.spark=halo((255,227,95),32)
        self.tip=pygame.transform.smoothscale(self.spark,(60,18))

    def parameters(self,drop):
        state=drop.state
        warning=state=='warning'
        u=1-drop.timer/DELIVERY.warning if warning else 1
        opening=(1-drop.timer/DELIVERY.opening if state=='opening' else
                 1 if state in ('falling','available','held') or drop.beam_fade>0 else 0)
        fade=1 if state in ('warning','opening','falling') else max(0,drop.beam_fade/DELIVERY.dissolve)
        return dict(spark=ease(u/.18)*fade,
                    ring=ease((u-.18)/.65)*fade,
                    portal=ease((u-.40)/.60)*fade,
                    beam=ease(opening)*fade,
                    beam_growth=ease(opening),
                    material=ease((opening-.55)/.45),
                    stage=max(0,min(5,(u-.10)/.9*5)),fade=fade)

    def draw(self,surface,drop,t):
        state=drop.state
        falling=state=='falling' and drop.sky_drop
        signal=state in ('warning','opening') or falling or drop.beam_fade>0
        p=self.parameters(drop)
        x,y=drop.x,drop.portal_y
        if signal:
            self.lines.fill((0,0,0,0))
            # O feixe vem de fora da tela: sem portal ornamental sobre a arena.
            opacity=p['beam']
            growth=p['beam_growth']
            bottom=round(self.floor*growth)
            if bottom>0 and opacity>0:
                # Halo largo e transparente; vários filamentos estreitos.
                self.beam.set_alpha(round(255*opacity))
                self.lines.blit(self.beam,(0,0),area=(0,0,220,bottom))
                for dx,width,a in ((-27,1,160),(-17,2,210),(-6,5,210),
                                   (0,2,255),(9,2,175),(23,1,140)):
                    pulse=.9+.1*math.sin(drop.effect_age*3+dx)
                    pygame.draw.line(self.lines,(255,228,91,round(a*opacity*pulse)),
                                     (110+dx,0),(110+dx,bottom),width)
                for i in range(24):
                    age=drop.effect_age
                    px=110+math.sin(i*5.7+age*.6)*(16+i%6*6)
                    py=(age*(38+i*2)+i*41)%max(1,self.floor)
                    if py<bottom:
                        a=round((100+90*math.sin(i+age*2)**2)*opacity)
                        size=2+i%3
                        pygame.draw.rect(self.lines,(255,226,70,a),(px,py,size,size))
            marker=p['ring']
            # Elipse segmentada ancorada no ponto real de queda.
            radius=60+3*math.sin(drop.effect_age*3)
            box=pygame.Rect(round(110-radius),self.floor-11,round(radius*2),18)
            for i in range(10):
                a=i*math.tau/10
                pygame.draw.arc(self.lines,(255,224,54,round(235*marker)),box,
                                a,a+.43,3)
            surface.blit(self.lines,(round(x-110),0))
            self.floor_light.set_alpha(round(145*marker))
            surface.blit(self.floor_light,(x-100,self.floor-13))
        if state=='opening':
            opacity=p['material']
            if opacity:
                pan(surface,(x,drop.y),drop.angle,.2+.8*ease(opacity),opacity=round(opacity*255))
        elif state in ('falling','available'):
            scale=1
            if state=='available' and drop.impact_age<DELIVERY.impact_compression:
                scale=1-.04*math.sin(math.pi*drop.impact_age/DELIVERY.impact_compression)
            pan(surface,(x,drop.y),drop.angle,scale)

    def draw_collection(self,surface,drop):
        if not drop.collection:return
        f,start,elapsed=drop.collection
        u=min(1,elapsed/DELIVERY.pickup_flight)
        point=start.lerp(f.weapon_center,1-(1-u)**3)+pygame.Vector2(0,-math.sin(u*math.pi)*24)
        aim=f.swing_vector() if f.attack_time>0 and f.windup<=0 else f.aim
        angle=165-math.degrees(math.atan2(aim.y,aim.x))
        start_angle=drop.collection_angle
        delta=(angle-start_angle+180)%360-180
        pan(surface,point,start_angle+delta*ease(u),1-u*.15)

import random
import pygame


class Particles:
    LIMIT=180

    def __init__(self):
        self.items=[]
        self.limit=self.LIMIT
        self.layer=pygame.Surface((1280,720),pygame.SRCALPHA)
        self.rng=random.Random(51)

    def burst(self,position,color,count=14,direction=0,style="spark"):
        count=max(1,round(count*self.limit/self.LIMIT))
        vector=pygame.Vector2(direction,0) if isinstance(direction,(int,float)) else pygame.Vector2(direction)
        for _ in range(min(count,self.limit-len(self.items))):
            v=pygame.Vector2(self.rng.uniform(-160,160),self.rng.uniform(-230,30))
            if vector.length_squared()>0: v+=vector*self.rng.uniform(80,220)
            if style=='metal': v*=1.25
            if style=='dust': v.update(self.rng.uniform(-75,75),self.rng.uniform(-35,-8))
            life=self.rng.uniform(.18,.4) if style!="confetti" else self.rng.uniform(1,2)
            self.items.append([pygame.Vector2(position),v,life,life,color,style])

    def update(self,dt):
        for p in self.items:
            p[0]+=p[1]*dt
            p[1].y+=(100 if p[5]=="confetti" else 25 if p[5]=="dust" else 450)*dt
            p[2]-=dt
        self.items=[p for p in self.items if p[2]>0][:self.limit]

    def draw(self,surface):
        if not self.items:return
        self.layer.fill((0,0,0,0))
        for pos,v,life,total,color,style in self.items:
            u=max(0,life/total)
            c=(*color,round(220*u*u))
            if style=='dust':
                radius=3+(1-u)*14
                pygame.draw.ellipse(self.layer,(*color,round(65*u)),
                                    (pos.x-radius,pos.y-radius*.5,radius*2,radius))
            elif style=='confetti':
                pygame.draw.rect(self.layer,c,(pos.x,pos.y,4,6))
            else:
                length=.025 if style=='trail' else .022 if style=='metal' else .012
                end=pos-v*length
                pygame.draw.line(self.layer,(*color,round(32*u)),pos,end,7)
                pygame.draw.line(self.layer,c,pos,end,2)
                if style=='metal':
                    pygame.draw.line(self.layer,(255,248,195,round(245*u)),pos,end,1)
        surface.blit(self.layer,(0,0))

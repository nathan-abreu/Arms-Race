"""Composição 2.5D sobre a arte v2, com luzes e máscaras preparadas uma vez.

O piso fica fixo. Recortes da própria arte, luzes e poeira têm profundidades
independentes. O relógio visual independe de áudio, IA e hit-stop.
"""
import math
import random
from functools import lru_cache

import pygame

from scripts.arena_layout import BACKGROUND_PATH, GROUND_Y, LEFT_EDGE, RIGHT_EDGE
from scripts.config import WIDTH, HEIGHT
from scripts.effects.neon import CYAN, PINK, BLUE, PURPLE, halo

LAYERS = ("distant", "crowd", "screens", "ring", "effects",
          "fighters", "foreground", "hud")
MAGENTA = (228, 45, 255)


@lru_cache(maxsize=4)
def load_background(path=BACKGROUND_PATH):
    try:
        raw = pygame.image.load(str(path)).convert()
        scale = max(WIDTH/raw.get_width(), HEIGHT/raw.get_height())
        size = (round(raw.get_width()*scale), round(raw.get_height()*scale))
        base = pygame.Surface((WIDTH, HEIGHT)).convert()
        base.fill((3, 7, 25))
        base.blit(pygame.transform.smoothscale(raw, size),
                  ((WIDTH-size[0])//2, (HEIGHT-size[1])//2))
        return base, True
    except (pygame.error, OSError):
        base = pygame.Surface((WIDTH, HEIGHT)).convert()
        for y in range(HEIGHT):
            pygame.draw.line(base, (3, 7+int(5*y/HEIGHT), 22+int(14*y/HEIGHT)),
                             (0,y), (WIDTH,y))
        return base, False


@lru_cache(maxsize=1)
def beam_frames():
    """Cones com bordas suaves e pivô fixo, sem rotação/alocação por quadro."""
    result = []
    for color in (CYAN, BLUE, MAGENTA):
        frames = []
        for angle in range(33):
            s = pygame.Surface((230, 360)).convert()
            s.fill((0, 0, 0))
            slope = (angle-16)/16*48
            for y in range(360):
                progress = y/360
                center, width = 115+slope*progress, 3+progress*60
                fade = math.sin(math.pi*progress)**.65
                for band in range(12, 0, -1):
                    brightness = .105*fade*(1-(band-1)/12)**1.4
                    tint = tuple(round(c*brightness) for c in color)
                    half = width*band/12
                    pygame.draw.line(s, tint, (center-half,y), (center+half,y))
            frames.append(s)
        result.append(tuple(frames))
    return tuple(result)


def masked_patch(base, normalized, brighten=0):
    """Recorte fotográfico com máscara poligonal e borda suavizada em cache."""
    poly = [(round(x*WIDTH), round(y*HEIGHT)) for x,y in normalized]
    rect = pygame.Rect(min(x for x,_ in poly), min(y for _,y in poly),
                       max(x for x,_ in poly)-min(x for x,_ in poly)+1,
                       max(y for _,y in poly)-min(y for _,y in poly)+1)
    rect = rect.inflate(12,12).clip(base.get_rect())
    mask = pygame.Surface(rect.size, pygame.SRCALPHA)
    local = [(x-rect.x,y-rect.y) for x,y in poly]
    pygame.draw.polygon(mask, (255,255,255,255), local)
    # Filtragem na preparação evita anéis de alpha e costuras no parallax.
    small=pygame.transform.smoothscale(mask,(max(1,rect.width//8),max(1,rect.height//8)))
    pygame.transform.smoothscale(small,rect.size,mask)
    mask.fill((255,255,255),special_flags=pygame.BLEND_RGB_MAX)
    patch = base.subsurface(rect).copy().convert_alpha()
    if brighten:
        patch.fill((brighten,)*3, special_flags=pygame.BLEND_RGB_ADD)
    patch.blit(mask, (0,0), special_flags=pygame.BLEND_RGBA_MULT)
    return rect, patch


class ImageArena:
    layers = LAYERS

    def __init__(self):
        self.base, self.image_found = load_background()
        self.stage = self.base.copy()
        dim = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        dim.fill((2,7,26,22))
        self.stage.blit(dim, (0,0))
        self.vignette = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for i in range(30):
            pygame.draw.rect(self.vignette, (1,3,15,max(0,22-i//2)),
                             (i*2,i,WIDTH-i*4,HEIGHT-i*2), 2)
        self.stage.blit(self.vignette, (0,0))
        # Exposição já pronta: uma única cópia de fundo por quadro.
        self.exposures = [self.stage]
        for alpha in (3,6):
            exposure = self.stage.copy()
            dim.fill((2,7,26,alpha))
            exposure.blit(dim, (0,0))
            self.exposures.append(exposure)
        self.overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        self.environment_frame = pygame.Surface((WIDTH,HEIGHT)).convert()
        self.overlay_rect = pygame.Rect(0,140,WIDTH,395)
        self.dark = pygame.Surface((WIDTH, HEIGHT)).convert()
        self.dark.fill((2,5,22))
        self.flash_wash = pygame.Surface((WIDTH,400),pygame.SRCALPHA)
        for y in range(400):
            alpha=round(27*math.sin(math.pi*y/400)**2)
            pygame.draw.line(self.flash_wash,(85,165,255,alpha),(0,y),(WIDTH,y))
        self.fog = pygame.Surface((WIDTH+12,110)).convert()
        self.fog.fill((0,0,0))
        for y in range(110):
            strength = math.sin(math.pi*y/110)**2
            pygame.draw.line(self.fog, (0,round(2*strength),round(5*strength)),
                             (0,y), (WIDTH+12,y))
        self.beams = beam_frames()
        self.follow_lights = (halo(CYAN,100), halo(PINK,100))
        self.floor_lights = [
            pygame.transform.smoothscale(halo(color,90), (240,28))
            for color in (CYAN,PINK,BLUE)]
        self.crowd_patches = [
            masked_patch(self.stage, quad) for quad in (
                ((.005,.408),(.245,.446),(.375,.472),(.625,.472),(.755,.446),
                 (.995,.408),(.995,.54),(.84,.55),(.5,.562),(.16,.55),(.005,.54)),
                ((.22,.365),(.38,.407),(.62,.407),(.78,.365),
                 (.78,.44),(.62,.459),(.38,.459),(.22,.44)))]
        self.foreground_rect, self.foreground = masked_patch(
            self.stage, ((0,.91),(.15,.86),(.30,.93),(.45,.90),(.59,.92),
                         (.73,.86),(.87,.90),(1,.87),(1,.999),(0,.999)))
        self.foreground_work = pygame.Surface(self.foreground.get_size(),pygame.SRCALPHA)
        self.screens, self.screen_masks, self.screen_polygons = [], [], []
        self.screen_fx = []
        quads = (
            ((.063,.202),(.209,.251),(.209,.380),(.063,.344)),
            ((.390,.255),(.610,.255),(.610,.382),(.390,.382)),
            ((.799,.253),(.939,.202),(.939,.344),(.799,.380)))
        boxes = ((.054,.19,.166,.225),(.377,.235,.249,.165),(.784,.19,.166,.225))
        for box,quad in zip(boxes,quads):
            rect = pygame.Rect(round(box[0]*WIDTH),round(box[1]*HEIGHT),
                               round(box[2]*WIDTH),round(box[3]*HEIGHT))
            poly = [(round(x*WIDTH),round(y*HEIGHT)) for x,y in quad]
            mask = pygame.Surface(rect.size,pygame.SRCALPHA)
            pygame.draw.polygon(mask,(255,255,255,255),
                                [(x-rect.x,y-rect.y) for x,y in poly])
            patch = self.base.subsurface(rect).copy().convert_alpha()
            patch.fill((18,25,38),special_flags=pygame.BLEND_RGB_ADD)
            patch.blit(mask,(0,0),special_flags=pygame.BLEND_RGBA_MULT)
            self.screens.append((rect,patch))
            self.screen_masks.append(mask)
            self.screen_polygons.append(poly)
            self.screen_fx.append(pygame.Surface(rect.size,pygame.SRCALPHA))
        self.trophy_rect, self.trophy = masked_patch(
            self.base, ((.453,.277),(.548,.277),(.548,.33),(.524,.355),
                        (.529,.387),(.476,.387),(.480,.355),(.453,.33)), 35)
        rng = random.Random(104)
        self.sticks = []
        for i in range(112):
            x = rng.uniform(.015,.985)
            y = rng.uniform(.47,.545) if .25<x<.75 else rng.uniform(.425,.53)
            if i%4 == 0 and .24<x<.76:
                y = rng.uniform(.415,.444)
            self.sticks.append((x*WIDTH,y*HEIGHT,rng.uniform(0,math.tau),
                                rng.choice((CYAN,MAGENTA,PURPLE)),
                                rng.uniform(4,8),rng.uniform(.8,2.1)))
        self.dust = [(rng.random()*WIDTH,rng.uniform(160,520),rng.random()*math.tau)
                     for _ in range(40)]
        self.rope_points = []
        for edge,center in ((.557,.575),(.605,.616),(.652,.655)):
            self.rope_points.append([
                (round((.17+.66*n/16)*WIDTH),
                 round((edge+(center-edge)*math.sin(n*math.pi/16))*HEIGHT))
                for n in range(17)])
        self.quality = 1
        self.enabled = True
        self.fighters, self.drop = (), None
        self.reset()

    def reset(self):
        """Recomeça eventos; todas as superfícies continuam em cache."""
        self.time = self.reaction = self.rope_pulse = 0.0
        self.crowd_energy = self.screen_energy = self.flash = 0.0
        self.damage = [0.0,0.0]
        self.rope_hits = []
        self.winner = None
        self.low_health = False
        self.parallax = 0.0
        self.dim_alpha = self.exposure_index = 0
        self.environment_key = None
        self.layer_offsets = {name:(0.0,0.0) for name in LAYERS}

    def configure(self, fighters, drop, settings):
        self.fighters, self.drop = fighters, drop
        self.quality = max(0,min(2,settings.particles))
        self.enabled = getattr(settings,"arena_effects",True)
        self.low_health = any(f.health<=28 and f.alive for f in fighters)
        self.winner = next((f for f in fighters if f.celebrating),None)

    def react(self, strength=1, side=None, *, event="hit", position=None):
        """Flash curto, torcida longa e vibração localizada têm envelopes próprios."""
        strength = max(0,min(1.5,strength))
        self.reaction = max(self.reaction,strength)
        self.environment_key = None
        self.flash = max(self.flash,min(1,strength))
        crowd = strength*(1.6 if event in ("combo","collect","knockout") else .55)
        self.crowd_energy = max(self.crowd_energy,min(2.2,crowd))
        self.screen_energy = max(self.screen_energy,strength)
        if side in (0,1):
            self.damage[side] = .22
        if event in ("strong","knockout","drop_impact") or strength>=1:
            self.rope_pulse = max(self.rope_pulse,strength)
        if position is not None:
            x,y = position
            rear_rope = WIDTH*.17<=x<=WIDTH*.83 and HEIGHT*.52<=y<=HEIGHT*.68
            if event=="rope" or rear_rope or (y>HEIGHT*.46 and
                    min(abs(x-WIDTH*LEFT_EDGE),abs(x-WIDTH*RIGHT_EDGE))<130):
                self.rope_hits.append([float(x),0.0,strength])
                self.rope_hits = self.rope_hits[-6:]

    def update(self, dt):
        self.time += dt
        self.reaction = max(0,self.reaction-dt*2.7)
        self.flash = max(0,self.flash-dt*9)
        self.crowd_energy = max(0,self.crowd_energy-dt*.65)
        self.screen_energy = max(0,self.screen_energy-dt*1.1)
        self.rope_pulse = max(0,self.rope_pulse-dt*2)
        self.damage[:] = [max(0,value-dt) for value in self.damage]
        for hit in self.rope_hits:
            hit[1] += dt
        self.rope_hits[:] = [h for h in self.rope_hits if h[1]<.65]
        target = ((sum(f.pos.x for f in self.fighters)/len(self.fighters)-WIDTH/2)/(WIDTH/2)
                  if self.fighters else 0)
        self.parallax += (max(-1,min(1,target))-self.parallax)*(1-math.exp(-dt*2.5))
        p,t = self.parallax,self.time
        self.layer_offsets.update(
            distant=(p*.5+math.sin(t*.16)*.35,0),
            crowd=(p*1.5+math.sin(t*.32)*.7,math.sin(t*.38)*.35),
            screens=(p*.8,0),ring=(0,0),
            effects=(p*4,math.sin(t*.25)*2),
            fighters=(0,0),foreground=(-p*3+math.sin(t*.29)*1.2,0),hud=(0,0))

    def _draw_beams(self, surface):
        t,q = self.time,self.quality
        dropping = self.drop and self.drop.state in ("opening","falling")
        lamps = ((.145,.104,0),(.855,.104,1))
        if q>=1:
            lamps += ((.05,.052,2),(.95,.052,2))
        if q==2:
            lamps += ((.224,.136,1),(.776,.136,0))
        dx = self.layer_offsets["distant"][0]
        for i,(x,y,color) in enumerate(lamps):
            angle = round(16+16*math.sin(t*(.28+i*.025)+i*1.7))
            beam = self.beams[color][angle]
            pos = (round(x*WIDTH-115+dx),round(y*HEIGHT))
            if not dropping or i<2:
                surface.blit(beam,pos,special_flags=pygame.BLEND_RGB_ADD)
                if self.reaction>.55:
                    surface.blit(beam,pos,special_flags=pygame.BLEND_RGB_ADD)
        if self.winner:
            beam = self.beams[0 if self.winner is self.fighters[0] else 2][16]
            pos = (round(self.winner.pos.x-115),round(self.winner.pos.y-360))
            surface.blit(beam,pos,special_flags=pygame.BLEND_RGB_ADD)
            surface.blit(beam,pos,special_flags=pygame.BLEND_RGB_ADD)

    def _draw_screens(self, surface):
        t,q = self.time,self.quality
        dx = round(self.layer_offsets["screens"][0])
        for i,(rect,patch) in enumerate(self.screens):
            side = 0 if i==0 else 1
            health = max(0,min(1,self.fighters[side].health/100)) if self.fighters else 1
            danger = i!=1 and health<=.28
            pulse = (1+math.sin(t*(5.5 if danger else 1.7)+i))*.5
            damage = self.damage[side]/.22 if i!=1 else 0
            patch.set_alpha(min(240,round(28+24*pulse+self.screen_energy*80+damage*145)))
            surface.blit(patch,(rect.x+dx,rect.y),special_flags=pygame.BLEND_ALPHA_SDL2)
            fx = self.screen_fx[i]
            fx.fill((0,0,0,0))
            if i!=1:
                tint = (255,35,90) if danger else CYAN if side==0 else PINK
                fx.fill((*tint,round((1-health)*(8+17*pulse))))
            if q:
                for y in range(int(t*9)%4,rect.height,4):
                    pygame.draw.line(fx,(5,10,40,22),(0,y),(rect.width,y))
                y = int(t*30+i*31)%rect.height
                pygame.draw.line(fx,(135,210,255,65),(0,y),(rect.width,y),2)
                if int(t*11+i*7)%53 in (0,1) or damage>.7:
                    gy = int(t*67+i*19)%rect.height
                    pygame.draw.rect(fx,(120,190,255,45+round(damage*60)),
                                     (rect.width*.2,gy,rect.width*.6,3))
            fx.blit(self.screen_masks[i],(0,0),special_flags=pygame.BLEND_RGBA_MULT)
            surface.blit(fx,(rect.x+dx,rect.y),special_flags=pygame.BLEND_ALPHA_SDL2)
        pulse = .5+.5*math.sin(t*2.4)
        self.trophy.set_alpha(round(40+55*pulse+min(100,self.screen_energy*60)))
        surface.blit(self.trophy,(self.trophy_rect.x+dx,self.trophy_rect.y),
                     special_flags=pygame.BLEND_ALPHA_SDL2)

    def _draw_crowd(self, overlay):
        t,q = self.time,self.quality
        energy = max(self.crowd_energy,1.25 if self.winner else 0)
        dx,dy = self.layer_offsets["crowd"]
        for i,(x,y,phase,color,length,speed) in enumerate(self.sticks[:(22,62,112)[q]]):
            sway = math.sin(t*speed+phase)*(2+energy*4)
            lift = max(0,math.sin(t*(speed+1.5)+phase))*energy*5
            alpha = round(65+25*math.sin(t*2+phase)+min(135,energy*65))
            start,end = (x+dx,y+dy-lift),(x+sway+dx,y-length+dy-lift)
            pygame.draw.line(overlay,(*color,alpha//4),start,end,5)
            pygame.draw.line(overlay,(*color,alpha),start,end,2)
            flash = math.sin(t*(.9+speed*.25)+phase)
            if flash>(.977 if energy>.6 else .998) and (q or i%3==0):
                pygame.draw.circle(overlay,(205,235,255,180),(round(x+dx),round(y+dy)),2)
                pygame.draw.line(overlay,(150,210,255,90),(x-4+dx,y+dy),(x+4+dx,y+dy))

    def _draw_ring(self, surface, overlay):
        t,q = self.time,self.quality
        for i,points in enumerate(self.rope_points):
            color = MAGENTA if i==1 else CYAN
            pulse = 14+9*math.sin(t*1.8+i)+min(100,self.rope_pulse*65)
            path,local_energy = [],0
            for x,y in points:
                offset = 0
                for hx,age,strength in self.rope_hits:
                    envelope = max(0,1-age/.65)*max(0,1-abs(x-hx)/290)*strength
                    offset += math.sin(age*38-abs(x-hx)*.022)*envelope*4
                    local_energy = max(local_energy,envelope)
                path.append((x,y+offset))
            alpha = min(200,round(pulse+local_energy*90))
            pygame.draw.lines(overlay,(*color,alpha//4),False,path,7)
            pygame.draw.lines(overlay,(*color,alpha),False,path,2)
            n = int(t*(2+i*.3)+i*5)%16
            pygame.draw.line(overlay,(*color,alpha+25),path[n],path[n+1],2)
        for x,age,strength in self.rope_hits:
            edge = LEFT_EDGE if x<WIDTH/2 else RIGHT_EDGE
            for i,y in enumerate((.565,.613,.658)):
                alpha = round(100*strength*max(0,1-age/.65))
                pygame.draw.line(overlay,(*(MAGENTA if i==1 else CYAN),min(200,alpha)),
                                 (WIDTH*edge-22,HEIGHT*y),(WIDTH*edge+22,HEIGHT*y+3),3)
        if q:
            old_clip = surface.get_clip()
            surface.set_clip((round(WIDTH*.105),round(HEIGHT*.69),round(WIDTH*.79),30))
            for i,light in enumerate(self.floor_lights[:(2 if q==1 else 3)]):
                x = 180+i*330+math.sin(t*.6+i)*55
                light.set_alpha(round(95+30*math.sin(t*1.4+i)))
                surface.blit(light,(x,HEIGHT*.695),special_flags=pygame.BLEND_ALPHA_SDL2)
            surface.set_clip(old_clip)
        for i in range((2,4,7)[q]):
            x = WIDTH*.11+(t*(30+i*3)+i*157)%(WIDTH*.78)
            y = HEIGHT*(.732 if i%2 else .689)
            pygame.draw.line(overlay,(120,220,255,round(70+40*math.sin(t*2+i))),
                             (x,y),(x+7,y),2)

    def draw(self, surface, _time=0):
        if not self.enabled:
            surface.blit(self.stage,(0,0))
            return
        # Luzes lentas/plateia a 30 Hz; corpos, reflexos, HUD e luz de
        # acompanhamento continuam na taxa do jogo. Eventos invalidam já.
        key=(int(self.time*30+1e-6),self.quality,self.low_health,
             tuple(f.health for f in self.fighters),
             self.drop.state if self.drop else None,id(self.winner))
        if key!=self.environment_key:
            self._draw_environment(self.environment_frame)
            self.environment_key=key
        surface.blit(self.environment_frame,(0,0))
        if self.quality:
            for f,light in zip(self.fighters,self.follow_lights):
                alpha=(170+25*math.sin(self.time*2))*(1-self.dim_alpha/255)
                light.set_alpha(round(alpha))
                surface.blit(light,(round(f.pos.x-100),round(f.pos.y-180)),
                             special_flags=pygame.BLEND_ALPHA_SDL2)

    def _draw_environment(self, surface):
        if not self.enabled:
            surface.blit(self.stage,(0,0))
            return
        t,q = self.time,self.quality
        self.exposure_index = min(2,int((.5+.5*math.sin(t*.43))*3))
        surface.blit(self.exposures[self.exposure_index],(0,0))
        if not self.image_found:
            pygame.draw.line(surface,(38,73,100),(round(WIDTH*LEFT_EDGE),round(HEIGHT*GROUND_Y)),
                             (round(WIDTH*RIGHT_EDGE),round(HEIGHT*GROUND_Y)),2)
        if q and self.image_found:
            dx,dy = self.layer_offsets["crowd"]
            for i,(rect,patch) in enumerate(self.crowd_patches):
                surface.blit(patch,(rect.x+round(dx*(1 if i==0 else .5)),rect.y+round(dy)),
                             special_flags=pygame.BLEND_ALPHA_SDL2)
        self._draw_beams(surface)
        self._draw_screens(surface)
        if q:
            dx,dy = self.layer_offsets["effects"]
            surface.blit(self.fog,(round(dx)-6,round(330+dy)),special_flags=pygame.BLEND_RGB_ADD)
        o = self.overlay
        o.fill((0,0,0,0),self.overlay_rect)
        self._draw_crowd(o)
        self._draw_ring(surface,o)
        for i,(x,y,phase) in enumerate(self.dust[:(6,20,40)[q]]):
            dx,dy = self.layer_offsets["effects"]
            px = (x+t*(3+i%3)+dx)%WIDTH
            py = y+math.sin(t*.6+phase)*8+dy
            pygame.draw.circle(o,(125,190,245,round(32+20*math.sin(t+phase))),
                               (round(px),round(py)),1)
            if q==2 and i%7==0 and math.sin(t*1.8+phase)>.94:
                pygame.draw.line(o,(140,215,255,105),(px,py),(px+2,py-3),1)
        surface.blit(o,self.overlay_rect.topleft,self.overlay_rect,
                     special_flags=pygame.BLEND_ALPHA_SDL2)
        if self.flash:
            self.flash_wash.set_alpha(round(self.flash*255))
            surface.blit(self.flash_wash,(0,80),special_flags=pygame.BLEND_ALPHA_SDL2)
        # O feixe dourado é desenhado pela cena depois deste escurecimento.
        dropping = self.drop and self.drop.state in ("warning","opening","falling")
        self.dim_alpha = 0
        if dropping or self.low_health:
            self.dim_alpha = ((48 if self.drop.state in ("opening","falling") else 21)
                              if dropping else round(10+5*math.sin(t*4)))
            self.dark.set_alpha(self.dim_alpha)
            surface.blit(self.dark,(0,0))

    def draw_foreground(self, surface):
        if not self.enabled:
            return
        if self.quality and self.image_found:
            dx,dy = self.layer_offsets["foreground"]
            # O recorte recebe a mesma exposição do fundo: sem borda clara
            # quando a entrega da Panela escurece a arena.
            foreground = self.foreground_work
            foreground.fill((0,0,0,0))
            foreground.blit(self.foreground,(0,0),special_flags=pygame.BLEND_RGBA_ADD)
            gain=round((255-self.dim_alpha)*(1-self.exposure_index*3/255))
            foreground.fill((gain,gain,gain),special_flags=pygame.BLEND_RGB_MULT)
            surface.blit(foreground,(self.foreground_rect.x+round(dx),
                                    self.foreground_rect.y+round(dy)),
                         special_flags=pygame.BLEND_ALPHA_SDL2)
        if self.quality==2:
            for i in range(8):
                x = 80+i*160+math.sin(self.time*.4+i)*9
                pygame.draw.circle(surface,(30,65,105),
                                   (round(x),round(HEIGHT*.89+math.sin(self.time+i)*4)),1)

"""Silhueta geométrica: preenchimento contínuo, borda de 1 px e halo de 6 px."""
import math
import pygame
from scripts.combat.weapon import FISTS
from scripts.effects.pan_art import pan
from scripts.entities.poses import pose, connected_pose
from scripts.arena_layout import SHOULDER_HEIGHT

INK=(5,18,37)
DRAW_ORDER=('back_limbs','torso','front_leg','head','front_arm','hands','weapon','effects')
SAMPLES=3


def limb(surface,color,points,width):
    for a,b in zip(points,points[1:]):
        delta=b-a
        normal=pygame.Vector2(-delta.y,delta.x)
        if normal.length_squared(): normal.scale_to_length(width*.5)
        pygame.draw.polygon(surface,color,[a+normal,b+normal,b-normal,a-normal])
    # Pequeno preenchimento quadrado une os segmentos, sem bolotas articulares.
    for point in points[1:-1]:
        pygame.draw.rect(surface,color,(point.x-width*.4,point.y-width*.4,width*.8,width*.8))


class FighterArt:
    draw_order=DRAW_ORDER

    def __init__(self):
        self.sprite=pygame.Surface((300,270),pygame.SRCALPHA)
        self.canvas=pygame.Surface((300*SAMPLES,270*SAMPLES),pygame.SRCALPHA)
        self.trail_canvas=pygame.Surface(self.canvas.get_size(),pygame.SRCALPHA)
        self.trail=pygame.Surface(self.sprite.get_size(),pygame.SRCALPHA)
        self.reflection=pygame.Surface((300,34),pygame.SRCALPHA)
        self.shadows=[]
        for level in range(16):
            shadow=pygame.Surface((112,20),pygame.SRCALPHA)
            width=82-level*2.8
            for extra,alpha in ((12,12),(6,24),(0,95-level*4)):
                pygame.draw.ellipse(shadow,(2,6,20,alpha),
                                    (56-(width+extra)/2,7-extra/6,width+extra,6+extra/3))
            self.shadows.append(shadow)
        self.points={}
        self.previous_points={}

    def draw_floor(self,surface,f):
        """Sombra projetada e reflexo simplificado da pose em buffers pequenos."""
        ground=f.visual_ground
        if not 134<=f.pos.x<=1146 or f.pos.y>ground+8:
            return
        height=max(0,ground-f.pos.y)
        level=min(15,round(height/12))
        source=186 if f.color[0]<100 else 1094
        shift=max(-12,min(12,(f.pos.x-source)*height*.00025))
        shift+=math.sin(f.animation_time*.4)*2
        surface.blit(self.shadows[level],(round(f.pos.x-56+shift),round(ground-7)))
        if not f.visual_quality or height>110:
            return
        r=self.reflection
        r.fill((0,0,0,0))
        # Projeção vertical comprimida acompanha salto e articulações reais.
        p={k:pygame.Vector2(150+v.x*.92+shift,-v.y*.075+height*.08+1)
           for k,v in self.points.items()}
        opacity=round((40 if f.visual_quality==2 else 23)*max(0,1-height/120))
        color=(*f.color,opacity)
        for keys in (('hip','knee_l','foot_l'),('hip','knee_r','foot_r'),
                     ('back_shoulder','back_elbow','back_hand'),
                     ('shoulder','elbow','hand'),('hip','shoulder','head')):
            pygame.draw.lines(r,color,False,[p[k] for k in keys],3)
        pygame.draw.ellipse(r,color,(p['head'].x-12,p['head'].y-1,24,3))
        old_clip=surface.get_clip()
        surface.set_clip(old_clip.clip(pygame.Rect(134,ground,1012,13)))
        surface.blit(r,(round(f.pos.x-150),round(ground+1)))
        surface.set_clip(old_clip)

    def update(self,dt,f):
        target=pose(f)
        if not f.grounded and f.velocity.y>=0:
            height=max(0,f.visual_ground-f.pos.y)
            extension=min(1,height/45)
            extension=extension*extension*(3-2*extension)
            for key in ('foot_l','foot_r'):
                target[key].y=-4+(target[key].y+4)*extension
        self.previous_points={k:v.copy() for k,v in self.points.items()}
        alpha=1-math.exp(-32*dt)
        for key,value in target.items():
            self.points[key]=self.points.get(key,value).lerp(value,alpha)
        if f.grounded:
            for key in ('foot_l','foot_r'): self.points[key]=target[key]
        if f.attack_time>0 and f.windup<=0:
            for key in ('shoulder','back_shoulder','hand','elbow','back_hand','back_elbow'):
                self.points[key]=target[key]
        self.points=connected_pose(self.points,f.facing)
        if not self.previous_points:
            self.previous_points={k:v.copy() for k,v in self.points.items()}

    def _body(self,s,p,f,color,extra=0,flat=False):
        # Polígonos gerados em alta resolução; nunca ampliamos um sprite pequeno.
        q=SAMPLES
        extra*=q
        rear=color if flat else tuple(round(v*.82) for v in color[:3])
        limb(s,rear,[p['hip'],p['knee_l'],p['foot_l']],14*q+extra)
        limb(s,rear,[p['back_shoulder'],p['back_elbow'],p['back_hand']],12*q+extra)
        h,sh=p['hip'],p['shoulder']
        pygame.draw.polygon(s,color,[sh+(-14*q-extra/2,-4*q),sh+(14*q+extra/2,-4*q),h+(13*q+extra/2,6*q),h+(-13*q-extra/2,6*q)])
        limb(s,color,[h,p['knee_r'],p['foot_r']],14*q+extra)
        for side,c in (('l',rear),('r',color)):
            foot=p['foot_'+side]
            pygame.draw.rect(s,c,(foot.x-(8 if f.facing>0 else 15)*q-extra/2,foot.y-6*q-extra/2,23*q+extra,10*q+extra))
        # Cabeça inclinável, ligada por pescoço curto; nenhuma linha interna.
        limb(s,color,[sh,p['head']+(0,12*q)],9*q+extra)
        tilt=f.facing*.19+max(-.16,min(.16,f.velocity.x*.00025))
        if not f.alive: tilt=-f.facing*1.25
        half=17*q+extra/2
        vertices=[p['head']+pygame.Vector2(x,y).rotate_rad(tilt) for x,y in ((-half,-half),(half,-half),(half,half),(-half,half))]
        pygame.draw.polygon(s,color,vertices)
        limb(s,color,[sh,p['elbow'],p['hand']],12*q+extra)
        if f.punch_arm==1 and (f.attack_time>0 or f.windup>0):
            limb(s,rear,[p['back_shoulder'],p['back_elbow'],p['back_hand']],12*q+extra)
        for key,c in (('back_hand',rear),('hand',color)):
            hand=p[key]
            pygame.draw.rect(s,c,(hand.x-6*q-extra/2,hand.y-6*q-extra/2,12*q+extra,12*q+extra))

    def draw(self,surface,f,alpha=1,position=None):
        if not self.points: self.update(1,f)
        s=self.canvas;s.fill((0,0,0,0))
        self.trail_canvas.fill((0,0,0,0))
        origin=pygame.Vector2(150,218)*SAMPLES
        blended={k:self.previous_points.get(k,v).lerp(v,alpha) for k,v in self.points.items()}
        self.rendered_points=connected_pose(blended,f.facing)
        p={k:v*SAMPLES+origin for k,v in self.rendered_points.items()}
        color=(249,255,255) if f.flash_time>0 else f.color
        if f.visual_quality:
            self._body(s,p,f,(*f.color,10),extra=10,flat=True)
            self._body(s,p,f,(*f.color,28),extra=4,flat=True)
        self._body(s,p,f,INK,extra=.75,flat=True)
        self._body(s,p,f,color)
        weapon=f.attack_weapon if f.attack_time>0 else f.inventory.weapon
        aim=f.swing_vector() if f.attack_time>0 and f.windup<=0 else (f.aim if f.aim_locked else pygame.Vector2(f.facing,0))
        if f.attack_time>0 and f.windup<=0:
            progress=1-f.attack_time/f.attack_duration
            # Rastro afilado segue a trajetória real de colisão.
            armed=weapon is not FISTS
            tint=(255,218,68) if armed else f.color
            history=min(progress,.48 if armed else .24)
            samples=[]
            for i in range(17):
                u=i/16
                time=progress-history*(1-u)
                direction=f.swing_vector(time)
                radius=f.strike_reach(time)
                center=origin+(pygame.Vector2(0,-SHOULDER_HEIGHT)+direction*radius)*SAMPLES
                width=(17 if armed else 6)*math.sin(u*math.pi*.85)*SAMPLES
                samples.append((center,direction,width,u))
            fade=min(1,progress/.12)*min(1,(1-progress)/.22)
            for spread,opacity in ((1.5,18),(1,75),(.45,170)):
                for a,b in zip(samples,samples[1:]):
                    ca,da,wa,ua=a;cb,db,wb,ub=b
                    polygon=[ca+da*wa*spread,cb+db*wb*spread,
                             cb-db*wb*spread,ca-da*wa*spread]
                    pygame.draw.polygon(self.trail_canvas,(*tint,round(opacity*ub*fade)),polygon)
            edge=[c+d*w*.5 for c,d,w,u in samples]
            if history>0:
                pygame.draw.lines(self.trail_canvas,(255,247,171,round(220*fade)) if armed else
                                  (162,255,255,round(200*fade)),False,edge,2*SAMPLES)
        pygame.transform.smoothscale(s,self.sprite.get_size(),self.sprite)
        if weapon is not FISTS and f.pickup_time<=0:
            # Mesmo socket interpolado. O PNG é reduzido à escala de jogo,
            # sem ampliar o pequeno cache da Panela para a tela de amostragem.
            pan(self.sprite,p['hand']/SAMPLES+aim*22,
                165-math.degrees(math.atan2(aim.y,aim.x)),.85)
        pos=f.pos if position is None else position
        x,y=pos.x-150,pos.y-218
        self.draw_floor(surface,f)
        pygame.transform.smoothscale(self.trail_canvas,self.trail.get_size(),self.trail)
        surface.blit(self.trail,(round(x),round(y)))
        surface.blit(self.sprite,(round(x),round(y)))

    def draw_bones(self,surface,f,alpha=1):
        root=f.previous_pos.lerp(f.pos,alpha)
        p={k:root+v for k,v in getattr(self,'rendered_points',self.points).items()}
        for keys in (('hip','knee_l','foot_l'),('hip','knee_r','foot_r'),
                     ('shoulder','elbow','hand'),('back_shoulder','back_elbow','back_hand'),
                     ('hip','shoulder','head')):
            pygame.draw.lines(surface,(255,230,65),False,[p[k] for k in keys],1)
            for key in keys: pygame.draw.circle(surface,(255,230,65),p[key],2)

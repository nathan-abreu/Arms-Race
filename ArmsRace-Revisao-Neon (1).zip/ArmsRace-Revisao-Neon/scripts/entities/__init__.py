"""Combatentes e controle."""

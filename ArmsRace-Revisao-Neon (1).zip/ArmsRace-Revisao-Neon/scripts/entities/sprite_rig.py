"""Rig hierárquico dos PNGs: sockets compartilhados, IK e composição 2×."""
import json
import math
from dataclasses import dataclass
from functools import lru_cache
import pygame
from scripts.config import ROOT
from scripts.entities.fighter_art import FighterArt
from scripts.entities.poses import pose
from scripts.combat.weapon import FISTS
from scripts.effects.pan_art import pan

SCALE=.09
SAMPLES=2
PARTS=ROOT/'assets/personagens/jogador/partes'


@lru_cache(maxsize=1)
def pieces():
    manifest=json.loads((PARTS/'manifest.json').read_text(encoding='utf-8'))
    result={}
    for name,data in manifest.items():
        image=pygame.image.load(str(PARTS/(name+'.png'))).convert_alpha()
        result[name]=(image,pygame.Rect(data['content']))
    return result


def smooth(u):
    u=max(0,min(1,u));return u*u*(3-2*u)


@dataclass
class Bone:
    name: str
    parent: str | None
    origin: pygame.Vector2
    pivot: pygame.Vector2
    angle: float
    local_angle: float
    socket: pygame.Vector2 | None = None

    def point(self,source):
        return self.origin+(pygame.Vector2(source)-self.pivot).rotate_rad(self.angle)*SCALE


class SpriteFighterArt(FighterArt):
    def __init__(self):
        super().__init__()
        self.canvas=pygame.Surface((300*SAMPLES,270*SAMPLES),pygame.SRCALPHA)
        self.parts=pieces()
        self.images={n:pygame.transform.smoothscale(s,(round(s.get_width()*SCALE*SAMPLES),
                                                      round(s.get_height()*SCALE*SAMPLES)))
                     for n,(s,_) in self.parts.items()}
        self.bones={};self.previous_bones={};self.joints={}
        self.state=None;self.blend_age=.1;self.blend_from={}
        self.previous_points={}
        self.pose_points={}

    def uv(self,name,uv):
        r=self.parts[name][1]
        return pygame.Vector2(r.x+r.w*uv[0],r.y+r.h*uv[1])

    def add(self,name,parent,socket,pivot,angle):
        if name in self.previous_bones:
            previous=self.previous_bones[name][1]
            angle=previous+(angle-previous+math.pi)%math.tau-math.pi
        origin=(self.bones[parent].point(self.uv(parent,socket)) if parent else pygame.Vector2(socket))
        relative=angle-self.bones[parent].angle if parent else angle
        self.bones[name]=Bone(name,parent,origin,self.uv(name,pivot),angle,relative,
                              self.uv(parent,socket) if parent else None)
        return self.bones[name]

    def chain(self,upper,lower,tip,parent,socket,up_pivot,up_end,low_pivot,low_end,
              tip_pivot,target,bend,tip_angle=None):
        start=self.bones[parent].point(self.uv(parent,socket))
        u=self.uv(upper,up_end)-self.uv(upper,up_pivot)
        v=self.uv(lower,low_end)-self.uv(lower,low_pivot)
        a,b=u.length()*SCALE,v.length()*SCALE
        delta=target-start
        distance=max(.001,min(a+b-.001,max(abs(a-b)+.001,delta.length())))
        heading=math.atan2(delta.y,delta.x)
        angle=heading+bend*math.acos(max(-1,min(1,(a*a+distance*distance-b*b)/(2*a*distance))))
        elbow=start+pygame.Vector2(math.cos(angle),math.sin(angle))*a
        end=start+delta.normalize()*distance if delta.length_squared() else start+pygame.Vector2(distance,0)
        first=angle-math.atan2(u.y,u.x)
        second=math.atan2(end.y-elbow.y,end.x-elbow.x)-math.atan2(v.y,v.x)
        self.add(upper,parent,socket,up_pivot,first)
        self.add(lower,upper,up_end,low_pivot,second)
        self.add(tip,lower,low_end,tip_pivot,second if tip_angle is None else tip_angle)
        return start,elbow,end

    def solve(self,points,f):
        d=f.facing
        p={k:pygame.Vector2(v.x*d,v.y) for k,v in points.items()}
        self.bones={}
        hip=p['hip']+(0,13)
        lean=max(-.16,min(.16,(p['shoulder'].x-p['hip'].x)*.007))
        self.add('quadril',None,hip,(.5,.58),lean*.18)
        self.add('tronco','quadril',(.5,.05),(.5,.90),lean)
        self.add('pescoco','tronco',(.5,.08),(.5,.92),lean*.45)
        self.add('cabeca','pescoco',(.5,.12),(.5,.90),lean*.25)
        joints={}
        for side,front in (('tras',False),('frente',True)):
            arm=self.chain('braco_superior_'+side,'antebraco_'+side,'punho_'+side,'tronco',
                (.85,.30) if front else (.20,.33),(.18,.45),(.92,.75),(.08,.50),(.91,.62),
                (.12,.56),p['hand' if front else 'back_hand'],1)
            suffix='r' if front else 'l'
            footname='pe_'+side
            sole=self.uv(footname,(.46,.95))-self.uv(footname,(.25,.19))
            target=p['foot_'+suffix]+(0,4)-sole*SCALE
            leg=self.chain('coxa_'+side,'canela_'+side,footname,'quadril',
                (.76,.58) if front else (.25,.58),(.64,.19),(.78,.86),(.38,.15),(.79,.86),
                (.25,.19),target,-1,0)
            joints.update({('shoulder' if front else 'back_shoulder'):arm[0],
                           ('elbow' if front else 'back_elbow'):arm[1],
                           ('hand' if front else 'back_hand'):arm[2],
                           'knee_'+suffix:leg[1],
                           'foot_'+suffix:leg[2]+sole*SCALE-(0,4)})
        joints['hip']=self.bones['quadril'].origin
        joints['head']=self.bones['cabeca'].point(self.uv('cabeca',(.5,.5)))
        self.joints={k:pygame.Vector2(v.x*d,v.y) for k,v in joints.items()}

    def update(self,dt,f):
        target=pose(f)
        if f.movement_state=='parado':
            breath=math.sin(f.animation_time*4)
            target['hip'].y+=breath*.6
            target['shoulder'].x+=breath*.45
        if not f.grounded and f.velocity.y>=0:
            # Estende as pernas antes do contato; a mistura de pouso não
            # deve deixar um pé visualmente suspenso após a colisão física.
            height=max(0,f.visual_ground-f.pos.y)
            extension=smooth(height/45)
            for key in ('foot_l','foot_r'):
                target[key].y=-4+(target[key].y+4)*extension
        if f.movement_state in ('correndo','iniciando_corrida'):
            travel=1 if f.velocity.x>=0 else -1
            for side,offset in (('r',0),('l',36)):
                phase=(f.stride_distance+offset)%72
                x=18-phase if phase<36 else -18+(phase-36)
                lift=0 if phase<36 else math.sin((phase-36)/36*math.pi)*19
                target['foot_'+side]=pygame.Vector2(x*travel,-4-lift)
        self.previous_points={k:v.copy() for k,v in self.points.items()}
        self.previous_bones={n:(b.origin.copy(),b.angle) for n,b in self.bones.items()}
        if self.state!=f.movement_state:
            self.state=f.movement_state;self.blend_age=0
            self.blend_from={k:v.copy() for k,v in self.pose_points.items()}
        self.blend_age+=dt
        weight=smooth(self.blend_age/.1)
        blended={k:self.blend_from.get(k,v).lerp(v,weight) for k,v in target.items()}
        # Ataques existentes conservam a trajetória usada na colisão.
        if f.attack_time>0 and f.windup<=0:
            for k in ('hand','back_hand'): blended[k]=target[k]
        self.pose_points=blended
        self.solve(blended,f)
        self.points={k:v.copy() for k,v in self.joints.items()}
        if not self.previous_bones: self.previous_bones={n:(b.origin.copy(),b.angle) for n,b in self.bones.items()}

    def draw(self,surface,f,alpha=1,position=None):
        if not self.points: self.update(1,f)
        canvas=self.canvas;canvas.fill((0,0,0,0))
        origin=pygame.Vector2(150,218)*SAMPLES
        order=('coxa_tras','canela_tras','pe_tras','braco_superior_tras','antebraco_tras','punho_tras',
               'quadril','tronco','pescoco','cabeca','coxa_frente','canela_frente','pe_frente',
               'braco_superior_frente','antebraco_frente','punho_frente')
        # Interpola ângulos locais e reavalia a hierarquia: nunca interpola
        # endpoints independentemente, o que poderia abrir as articulações.
        rendered={}
        for name,bone in self.bones.items():
            prev_pos,prev_angle=self.previous_bones.get(name,(bone.origin,bone.angle))
            angle=prev_angle+(bone.angle-prev_angle)*alpha
            if bone.parent:
                parent=self.bones[bone.parent]
                old_parent=self.previous_bones.get(bone.parent,(parent.origin,parent.angle))[1]
                local_old=prev_angle-old_parent
                local=local_old+(bone.local_angle-local_old)*alpha
                parent_pos,parent_angle=rendered[bone.parent]
                socket=(bone.origin-parent.origin).rotate_rad(-parent.angle)
                pos=parent_pos+socket.rotate_rad(parent_angle)
                angle=parent_angle+local
            else: pos=prev_pos.lerp(bone.origin,alpha)
            rendered[name]=(pos,angle)
        for name in order:
            bone=self.bones[name];pos,angle=rendered[name]
            image=self.images[name]
            rotated=pygame.transform.rotozoom(image,-math.degrees(angle),1)
            center=pygame.Vector2(self.parts[name][0].get_size())*.5
            offset=(center-bone.pivot).rotate_rad(angle)*SCALE*SAMPLES
            target=origin+pos*SAMPLES+offset
            canvas.blit(rotated,rotated.get_rect(center=(round(target.x),round(target.y))))
        self.rendered_bones=rendered
        pygame.transform.smoothscale(canvas,(300,270),self.sprite)
        if f.flash_time>0:
            self.sprite.fill((255,255,255),special_flags=pygame.BLEND_RGB_MAX)
        sprite=self.sprite if f.facing>0 else pygame.transform.flip(self.sprite,True,False)
        pos=f.pos if position is None else position
        self.draw_floor(surface,f)
        surface.blit(sprite,(round(pos.x-150),round(pos.y-218)))
        weapon=f.attack_weapon if f.attack_time>0 else f.inventory.weapon
        if weapon is not FISTS and f.pickup_time<=0:
            aim=f.swing_vector() if f.attack_time>0 and f.windup<=0 else f.aim
            joint=rendered['punho_frente'][0]
            hand=pos+pygame.Vector2(joint.x*f.facing,joint.y)+aim*22
            pan(surface,hand,165-math.degrees(math.atan2(aim.y,aim.x)),.85)

    def draw_bones(self,surface,f,alpha=1):
        root=f.previous_pos.lerp(f.pos,alpha)
        positions=getattr(self,'rendered_bones',{n:(b.origin,b.angle) for n,b in self.bones.items()})
        for name,bone in self.bones.items():
            point=positions[name][0]
            p=root+pygame.Vector2(point.x*f.facing,point.y)
            pygame.draw.circle(surface,(255,230,65),p,3)
            if bone.parent:
                parent=positions[bone.parent][0]
                q=root+pygame.Vector2(parent.x*f.facing,parent.y)
                pygame.draw.line(surface,(255,230,65),q,p,1)

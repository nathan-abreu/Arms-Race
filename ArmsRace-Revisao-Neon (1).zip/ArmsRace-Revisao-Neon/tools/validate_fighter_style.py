"""Capturas 1280×720 pela rota real da partida, sem ampliar os lutadores.

python -m tools.validate_fighter_style [--window]
Na janela: 1 guarda, 2 corrida, 3 salto, 4 soco, 5 Panela; Esc fecha.
Entradas preparadas verificam poses, não comprovam fluidez percebida.
"""
import argparse
import json
import os


def prepare(game, state):
    from scripts.config import FIXED_DT
    from scripts.combat.weapon import PAN
    game.start_match()
    m=game.scene
    m.flow.phase='fight'
    game.development.show_bones=False
    game.settings.shake=0
    for f,x in zip(m.fighters,(450,830)):
        f.pos.x=x;f.previous_pos=f.pos.copy()
        f.set_aim(f.shoulder+(f.facing*200,0))
        f.animate(1)
    if state=='panela':m.player.inventory.collect(PAN)
    steps={'guarda':30,'corrida':28,'salto':25,'ataque':13,'panela':13}[state]
    if state=='salto':
        for f in m.fighters:f.request_jump()
    if state in ('ataque','panela'):
        for f in m.fighters:f.attack()
    for _ in range(steps):
        for f in m.fighters:
            f.axis=f.facing if state=='corrida' else 0
            f.update(FIXED_DT,m.platforms)
        m.time+=FIXED_DT
        m.art.update(FIXED_DT)
        m.camera.update(FIXED_DT,m.fighters)
    m.render_alpha=1
    m.hud.update(1,m.fighters)
    m.draw(game.screen)
    return m


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--window',action='store_true')
    args=parser.parse_args()
    if not args.window:os.environ['SDL_VIDEODRIVER']='dummy'
    os.environ['SDL_AUDIODRIVER']='dummy'
    import pygame
    from scripts.config import ROOT
    from scripts.game import Game
    game=Game('ringue',audio_enabled=False,developer=True)
    out=ROOT/'.local/fighter_style';out.mkdir(parents=True,exist_ok=True)
    states=('guarda','corrida','salto','ataque','panela')
    report={'driver':pygame.display.get_driver(),'size':[1280,720],
            'input':'Preparada; física e renderização reais, sem CPU automática.',
            'perceptual_review':'Capturas estáticas; não comprovam fluidez interativa.',
            'states':{}}
    for state in states:
        m=prepare(game,state)
        pygame.image.save(game.screen,str(out/(state+'.png')))
        report['states'][state]=[
            {'renderer':type(f.art).__name__,'movement':f.movement_state,
             'position':list(f.pos),'joints':{k:list(v) for k,v in f.art.points.items()}}
            for f in m.fighters]
    (out/'validacao.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(out,flush=True)
    if args.window:
        prepare(game,'guarda')
        running=True
        while running:
            for event in pygame.event.get():
                if event.type==pygame.QUIT:running=False
                if event.type==pygame.KEYDOWN:
                    if event.key==pygame.K_ESCAPE:running=False
                    if pygame.K_1<=event.key<=pygame.K_5:
                        prepare(game,states[event.key-pygame.K_1])
            game.viewport.present(game.screen,game.window)
            pygame.display.flip();game.clock.tick(60)
    game.audio.stop();pygame.quit()


if __name__=='__main__':main()

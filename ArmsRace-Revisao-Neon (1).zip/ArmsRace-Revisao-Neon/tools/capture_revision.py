"""Comparação reproduzível com entradas programadas, não um teste humano.

python -m tools.capture_revision [--video]
MP4 requer ffmpeg no PATH; o jogo e as capturas PNG não requerem ffmpeg.
"""
import argparse
import os
from pathlib import Path
import subprocess


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--video',action='store_true')
    args=parser.parse_args()
    os.environ['SDL_VIDEODRIVER']='dummy'
    os.environ['SDL_AUDIODRIVER']='dummy'
    import pygame
    from scripts.game import Game
    from scripts.config import FIXED_DT,ROOT
    from scripts.combat.weapon import PAN
    out=ROOT/'revisao_visual';out.mkdir(exist_ok=True)
    game=Game('ringue',audio_enabled=False,developer=True)
    game.development.show_bones=False
    game.settings.shake=0
    def reset(xs=(360,920)):
        game.start_match();m=game.scene;m.flow.phase='fight'
        for f,x in zip(m.fighters,xs):
            f.pos.x=x;f.previous_pos=f.pos.copy();f.set_aim(f.shoulder+(200*f.facing,0));f.animate(1)
        return m
    m=reset()
    m.draw(game.screen);pygame.image.save(game.screen,str(out/'01_guarda.png'))
    m.trigger_delivery();m.drop.x=640;m.drop.previous=(640,m.drop.y,m.drop.angle)
    saved=False
    for _ in range(300):
        m.simulate(FIXED_DT)
        if not saved and m.drop.state=='falling' and m.drop.y>=365:
            m.render_alpha=1;m.draw(game.screen)
            pygame.image.save(game.screen,str(out/'02_entrega.png'));saved=True
    m=reset((540,640));m.player.inventory.collect(PAN);m.player.attack()
    for _ in range(13):m.simulate(FIXED_DT)
    m.render_alpha=1;m.draw(game.screen);pygame.image.save(game.screen,str(out/'03_contato.png'))
    if args.video:
        pipe=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24',
                '-s','1280x720','-r','60','-i','-','-an','-c:v','libx264','-preset','fast',
                '-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out/'demonstracao.mp4')],stdin=subprocess.PIPE)
        labels=['Guarda e entrega','Corrida e inversao','Salto baixo e alto','Soco: erro e contato','Panela: golpe e contato']
        font=pygame.font.Font(None,22)
        try:
            for section in range(5):
                m=reset((540,640) if section in (3,4) else (360,920))
                if section==0:
                    m.trigger_delivery();m.drop.x=640;m.drop.previous=(640,m.drop.y,m.drop.angle)
                if section==3:
                    m.enemy.pos.x=920;m.enemy.previous_pos=m.enemy.pos.copy()
                if section==4:m.player.inventory.collect(PAN)
                for frame in range(180):
                    if section==1:m.player.axis=1 if frame<60 else -1 if frame<120 else 0
                    if section==2:
                        if frame in (10,80):m.player.request_jump()
                        if frame==16:m.player.release_jump()
                    if section in (3,4):
                        if section==3 and frame==65:
                            m.enemy.pos.x=640;m.enemy.previous_pos=m.enemy.pos.copy()
                        if frame in (20,80):m.player.attack()
                    for _ in range(2):m.simulate(FIXED_DT)
                    m.render_alpha=1;m.draw(game.screen)
                    pygame.draw.rect(game.screen,(5,10,25),(12,116,400,27))
                    game.screen.blit(font.render(labels[section]+' | entrada programada',True,(210,233,245)),(19,121))
                    pipe.stdin.write(pygame.image.tobytes(game.screen,'RGB'))
        finally:
            pipe.stdin.close()
            if pipe.wait()!=0:raise RuntimeError('Falha na gravação ffmpeg')
    game.audio.stop();pygame.quit()
    print(out)


if __name__=='__main__':main()

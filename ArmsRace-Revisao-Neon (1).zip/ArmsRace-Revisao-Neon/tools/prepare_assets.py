"""Audita PNGs e extrai peças por conectividade alpha, sem redimensionar a arte."""
import hashlib
import json
import os
from collections import deque
from pathlib import Path
import pygame

ROOT=Path(__file__).resolve().parents[1]
CHAR=ROOT/'assets/personagens/jogador'
PAN=ROOT/'assets/armas/panela'
NAMES={
    'nucleo': ('cabeca','pescoco','tronco','quadril'),
    'bracos': ('braco_superior_frente','antebraco_frente','punho_frente',
               'braco_superior_tras','antebraco_tras','punho_tras'),
    'pernas': ('coxa_frente','canela_frente','pe_frente',
               'coxa_tras','canela_tras','pe_tras')}


def border_black(surface, tolerance=8):
    """Flood fill 4-conexo, atravessando transparência e apenas preto neutro.

    Não usa chroma key global: regiões escuras fechadas e todo azul ficam.
    """
    w,h=surface.get_size()
    raw=bytearray(pygame.image.tobytes(surface,'RGBA'))
    visited=bytearray(w*h)
    todo=deque([*range(w),*range((h-1)*w,h*w),
                *(y*w for y in range(h)),*(y*w+w-1 for y in range(h))])
    removed=0
    while todo:
        n=todo.pop()
        if visited[n]: continue
        visited[n]=1
        i=n*4
        rgb=raw[i:i+3]
        if raw[i+3] and (max(rgb)>tolerance or max(rgb)-min(rgb)>2): continue
        if raw[i+3]: raw[i+3]=0;removed+=1
        x,y=n%w,n//w
        if x: todo.append(n-1)
        if x<w-1: todo.append(n+1)
        if y: todo.append(n-w)
        if y<h-1: todo.append(n+w)
    return pygame.image.frombytes(bytes(raw),(w,h),'RGBA'),removed


def checker(surface,path):
    scale=min(1,1200/surface.get_width(),850/surface.get_height())
    size=tuple(max(1,round(v*scale)) for v in surface.get_size())
    result=pygame.Surface(size)
    for y in range(0,size[1],20):
        for x in range(0,size[0],20):
            result.fill((63,68,82) if (x//20+y//20)%2 else (155,160,174),(x,y,20,20))
    result.blit(pygame.transform.smoothscale(surface,size),(0,0))
    pygame.image.save(result,str(path))


def components(surface,count,rows=False):
    # O limiar só identifica os componentes; os pixels salvos mantêm alpha/RGB.
    cs=pygame.mask.from_surface(surface,16).connected_components(1000)
    rects=[c.get_bounding_rects()[0] for c in cs]
    if len(rects)!=count:
        raise ValueError(f'Esperados {count} componentes; encontrados {len(rects)}')
    if rows:
        rects=sorted(rects,key=lambda r:r.centery)
        rects=sorted(rects[:3],key=lambda r:r.x)+sorted(rects[3:],key=lambda r:r.x)
    else: rects.sort(key=lambda r:r.x)
    return rects


def prepare():
    out=ROOT/'.local/asset_rig';out.mkdir(parents=True,exist_ok=True)
    (out/'transparencia').mkdir(exist_ok=True)
    parts=CHAR/'partes';parts.mkdir(exist_ok=True)
    report={};manifest={}
    paths=[*(CHAR/(n+'.png') for n in NAMES),*(PAN/(n+'.png') for n in ('panela','feixe','portal','portal_frames'))]
    for path in paths:
        before=path.read_bytes();s=pygame.image.load(str(path))
        had_alpha=bool(s.get_masks()[3]);s=s.convert_alpha()
        # Só varre milhões de pixels quando existe preto opaco na borda.
        w,h=s.get_size()
        edge=[*(s.get_at((x,y)) for y in (0,h-1) for x in range(w)),
              *(s.get_at((x,y)) for x in (0,w-1) for y in range(h))]
        removed=0
        if any(c.a and max(c[:3])<=8 and max(c[:3])-min(c[:3])<=2 for c in edge):
            s,removed=border_black(s)
            if removed:
                backup=out/'originais';backup.mkdir(exist_ok=True)
                if not (backup/path.name).exists(): (backup/path.name).write_bytes(before)
                pygame.image.save(s,str(path))
        rgba=pygame.image.tobytes(s,'RGBA');alpha=rgba[3::4]
        bounds=s.get_bounding_rect(min_alpha=16)
        report[str(path.relative_to(ROOT))]=dict(size=list(s.get_size()),alpha_channel=had_alpha,
            transparent=alpha.count(0),opaque=alpha.count(255),partial=len(alpha)-alpha.count(0)-alpha.count(255),
            margins=[bounds.left,bounds.top,w-bounds.right,h-bounds.bottom],
            removed_border_black=removed,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        checker(s,out/'transparencia'/(path.stem+'.png'))
        if path.stem in NAMES:
            rects=components(s,len(NAMES[path.stem]),path.stem!='nucleo')
            for name,r in zip(NAMES[path.stem],rects):
                crop=r.inflate(24,24).clip(s.get_rect())
                piece=s.subsurface(crop).copy()
                pygame.image.save(piece,str(parts/(name+'.png')))
                manifest[name]=dict(sheet=path.name,rect=list(crop),content=list(r.move(-crop.x,-crop.y)),
                                    size=list(piece.get_size()))
                checker(piece,out/'transparencia'/(name+'.png'))
    # A folha tem seis estágios de tamanhos diferentes, não células iguais.
    # Limites calibrados nos intervalos entre os respectivos núcleos luminosos.
    sheet=pygame.image.load(str(PAN/'portal_frames.png')).convert_alpha()
    regions=((20,210),(210,500),(500,850),(850,1220),(1220,1660),(1660,2172))
    frames=PAN/'frames';frames.mkdir(exist_ok=True)
    for i,(left,right) in enumerate(regions):
        r=pygame.Rect(left,0,right-left,sheet.get_height())
        frame=sheet.subsurface(r).copy()
        pygame.image.save(frame,str(frames/f'portal_{i}.png'))
    (parts/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'assets.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return report,manifest


if __name__=='__main__':
    os.environ.setdefault('SDL_VIDEODRIVER','dummy')
    pygame.display.init();pygame.display.set_mode((1,1))
    prepare();pygame.quit()

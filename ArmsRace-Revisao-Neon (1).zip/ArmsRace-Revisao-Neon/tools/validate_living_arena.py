"""Capturas e custo real por quadro, em três níveis, sem áudio ou janela.

python -m tools.validate_living_arena --frames 600
O benchmark inclui simulação, arena, lutadores, HUD e apresentação SDL dummy.
"""
import argparse
import json
import os
from statistics import mean
from time import perf_counter


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--frames",type=int,default=600)
    parser.add_argument("--paced-seconds",type=float,default=15)
    parser.add_argument("--captures-only",action="store_true")
    args=parser.parse_args()
    if args.frames<60:
        parser.error("Use pelo menos 60 quadros.")
    if args.paced_seconds<=0:
        parser.error("A duração deve ser positiva.")
    os.environ["SDL_VIDEODRIVER"]="dummy"
    os.environ["SDL_AUDIODRIVER"]="dummy"
    import pygame
    from scripts.game import Game
    from scripts.config import FIXED_DT, ROOT
    from scripts.scenes.options import Options

    out=ROOT/".local"/"living_arena"
    out.mkdir(parents=True,exist_ok=True)
    game=Game("ringue",audio_enabled=False)

    def fresh():
        game.start_match()
        m=game.scene
        m.flow.phase="fight"
        for f in m.fighters:
            f.animate(1)
        return m

    def save(name):
        game.scene.draw(game.screen)
        pygame.image.save(game.screen,str(out/(name+".png")))

    m=fresh()
    game.settings.particles=2
    for i in range(8):
        m.art.update(.5)
        save(f"idle_{i}")
    m.art.react(1.0,side=1,event="combo",position=(950,420))
    save("combo")
    m=fresh()
    m.drop.state="falling"
    m.drop.x,m.drop.y=640,330
    save("drop")
    m=fresh()
    m.player.health=20
    save("low_health")
    m=fresh()
    m.art.react(.8,event="rope",position=(150,460))
    m.art.update(.08)
    save("ropes")
    m=fresh()
    m.enemy.health=0
    m.check_result()
    m.simulate(.12)
    save("knockout")
    for _ in range(40):
        m.simulate(FIXED_DT)
    save("victory")
    Options(game,m).draw(game.screen)
    pygame.image.save(game.screen,str(out/"options.png"))
    # Flipbook local, sem dependências ou servidor, para inspecionar o movimento.
    (out/"preview.html").write_text("""<!doctype html><meta charset="utf-8">
<title>Arena viva — prévia</title>
<style>body{background:#050b1c;color:#dffbff;font:18px system-ui;text-align:center}
img{width:min(96vw,1280px)}button{padding:10px;margin:10px}</style>
<p>Arena em repouso • capturas a cada 0,5 segundo • Alto</p>
<button onclick="playing=!playing">Pausar / continuar</button><br>
<img id="arena" src="idle_0.png" alt="Arena animada">
<script>let i=0,playing=true;setInterval(()=>{if(playing)
document.getElementById('arena').src=`idle_${++i%8}.png`},500)</script>""",encoding="utf-8")
    if args.captures_only:
        game.audio.stop()
        pygame.quit()
        return
    report={}
    for q,label in enumerate(("baixo","medio","alto")):
        game.settings.particles=q
        m=fresh()
        samples=[]
        arena_samples=[]
        for i in range(args.frames+60):
            if m.result:
                m=fresh()
            # Eventos visuais exercitados regularmente sem depender do áudio.
            if i%90==0:
                m.art.react(1,event="combo",side=i%2,position=(150,430))
            begin=perf_counter()
            m.simulate(FIXED_DT)
            m.draw(game.screen)
            game.viewport.present(game.screen,game.window)
            pygame.display.flip()
            elapsed=(perf_counter()-begin)*1000
            if i>=60:
                samples.append(elapsed)
            assert len(m.particles.items)<=game.settings.particle_limit
            assert len(m.art.rope_hits)<=6
        save(label)
        for _ in range(120):
            begin=perf_counter()
            m.art.update(FIXED_DT)
            m.art.draw(m.world)
            m.art.draw_foreground(m.world)
            arena_samples.append((perf_counter()-begin)*1000)
        report[label]=dict(frames=len(samples),work_mean_ms=round(mean(samples),3),
                           work_p95_ms=round(sorted(samples)[int(len(samples)*.95)],3),
                           throughput_fps=round(1000/mean(samples),2),
                           arena_mean_ms=round(mean(arena_samples),3))
        print(label,report[label],flush=True)
    report["environment"]=dict(driver=pygame.display.get_driver(),audio=game.audio.enabled,
                               resolution=list(game.screen.get_size()),pygame=pygame.version.ver)
    game.settings.particles=2
    m=fresh()
    start=perf_counter()
    frames=0
    accumulator=0
    paced_work=[]
    while perf_counter()-start<args.paced_seconds:
        elapsed=min(game.clock.tick_busy_loop(60)/1000,.1)
        begin=perf_counter()
        accumulator+=elapsed
        pygame.event.pump()
        while accumulator>=FIXED_DT:
            m.simulate(FIXED_DT)
            accumulator-=FIXED_DT
        if m.result and m.flow.result_age>1:
            m=fresh()
        m.draw(game.screen)
        game.viewport.present(game.screen,game.window)
        pygame.display.flip()
        paced_work.append((perf_counter()-begin)*1000)
        frames+=1
    duration=perf_counter()-start
    report["paced_high"]=dict(seconds=round(duration,2),frames=frames,
                              fps=round(frames/duration,2),
                              work_mean_ms=round(mean(paced_work),3),
                              work_p95_ms=round(sorted(paced_work)[int(len(paced_work)*.95)],3))
    print("alto limitado a 60",report["paced_high"],flush=True)
    (out/"benchmark.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    game.audio.stop()
    pygame.quit()


if __name__=="__main__":
    main()

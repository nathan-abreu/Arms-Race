"""Ferramentas locais de diagnóstico."""

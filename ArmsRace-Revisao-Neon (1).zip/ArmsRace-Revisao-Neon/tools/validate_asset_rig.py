"""Sequências reais do render interpolado, comparando 100% e 25%.

python -m tools.validate_asset_rig
Nenhuma medição headless é apresentada como avaliação humana de suavidade.
"""
import json
import argparse
import os
import statistics
from collections import defaultdict
from copy import copy
from pathlib import Path
from time import perf_counter


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stills-only',action='store_true',help='Atualiza montagem e estados sem regravar sequências')
    args=parser.parse_args()
    os.environ['SDL_VIDEODRIVER']='dummy'
    os.environ['SDL_AUDIODRIVER']='dummy'
    import pygame
    from scripts.config import ROOT,FIXED_DT
    from scripts.entities.player import Player
    from scripts.game import Game
    from scripts.ui.style import text
    from tools.prepare_assets import checker
    out=ROOT/'.local/asset_rig';out.mkdir(parents=True,exist_ok=True)
    game=Game('ringue',audio_enabled=False,developer=True)
    game.development.show_bones=False
    small=pygame.Surface((640,400)).convert()
    large=pygame.Surface((600,540),pygame.SRCALPHA)
    scratch=pygame.Surface((640,514)).convert()
    counts={};measurements={};states={}

    def hero(f,alpha,caption,bones=False):
        small.fill((7,13,30))
        center=f.previous_pos.lerp(f.pos,alpha).x
        for i in range(-18,19):
            x=round((i*40-center%40)*2+320)
            pygame.draw.line(small,(27,57,77),(x,345),(x,365),1)
        pygame.draw.line(small,(40,170,210),(0,345),(640,345),1)
        view=copy(f);view.pos=pygame.Vector2(320,340)
        f.art.draw(scratch,view,alpha,view.pos)
        pygame.transform.smoothscale(f.art.canvas,(600,540),large)
        small.blit(large,(20,-91))
        if bones:
            for bone in f.art.bones.values():
                p=pygame.Vector2(320+bone.origin.x*2,345+bone.origin.y*2)
                pygame.draw.circle(small,(255,220,80),p,3)
                if bone.parent:
                    parent=f.art.bones[bone.parent]
                    q=pygame.Vector2(320+parent.origin.x*2,345+parent.origin.y*2)
                    pygame.draw.line(small,(255,220,80),q,p,1)
        text(small,caption,(18,15),24)
        return small

    floor=[pygame.Rect(-10000,514,20000,30)]
    for speed,label in (() if args.stills_only else ((1,'normal'),(.25,'25'))):
        folder=out/('corrida_'+label);folder.mkdir(exist_ok=True)
        f=Player((320,514));f.grounded=True;f.animate(1)
        accumulator=0;sim_time=0;n=round(1.2/speed*60)
        for i in range(n):
            accumulator+=speed/60
            while accumulator+1e-10>=FIXED_DT:
                f.axis=1 if sim_time<.95 else 0
                f.update(FIXED_DT,floor)
                sim_time+=FIXED_DT;accumulator=max(0,accumulator-FIXED_DT)
            frame=hero(f,accumulator/FIXED_DT,f'Corrida {speed:.0%} | t={sim_time:.3f}s | {f.movement_state}')
            pygame.image.save(frame,str(folder/f'{i:04}.png'))
        counts['corrida_'+label]=n
        print('corrida',label,n,'quadros',flush=True)

    f=Player((320,514));f.grounded=True;f.animate(1)
    hero(f,1,'Guarda / respiracao',False)
    pygame.image.save(small,str(out/'personagem_montado.png'))
    checker(f.art.sprite,out/'personagem_alpha.png')
    hero(f,1,'Esqueleto / pivos',True)
    pygame.image.save(small,str(out/'personagem_ossos.png'))
    for i in range(300):
        t=i*FIXED_DT
        f.axis=1 if .15<t<.60 else 0
        if i==100:f.request_jump()
        if i==134:f.release_jump()
        f.update(FIXED_DT,floor)
        state=f.movement_state
        if state not in states:
            hero(f,1,state)
            pygame.image.save(small,str(out/('estado_'+state+'.png')))
            states[state]=round(t,4)

    if args.stills_only:
        game.audio.stop();pygame.quit()
        return

    for speed,label in ((1,'normal'),(.25,'25')):
        game.start_match();m=game.scene;m.flow.phase='fight'
        m.player.pos.x=220;m.enemy.pos.x=1100
        m.rng.seed(0);m.trigger_delivery()
        game.settings.particles=1
        folder=out/('panela_'+label);folder.mkdir(exist_ok=True)
        accumulator=0;sim_time=0;n=round(2.6/speed*60);work=[];delivery_states=set()
        selected=set()
        for i in range(n):
            begin=perf_counter()
            impact_seen=False
            accumulator+=speed/60
            while accumulator+1e-10>=FIXED_DT:
                m.simulate(FIXED_DT,defaultdict(bool))
                impact_seen=impact_seen or bool(m.drop.impact_event)
                sim_time+=FIXED_DT;accumulator=max(0,accumulator-FIXED_DT)
            m.render_alpha=accumulator/FIXED_DT
            m.draw(game.screen)
            work.append((perf_counter()-begin)*1000)
            delivery_states.add(m.drop.state)
            # Captura sem trocar a lógica da entrega por uma animação de teste.
            box=pygame.Rect(round(m.drop.x)-200,55,400,500)
            crop=game.screen.subsurface(box).copy()
            text(crop,f'{speed:.0%}  t={sim_time:.3f}s  {m.drop.state}',(8,470),19)
            pygame.image.save(crop,str(folder/f'{i:04}.png'))
            for at,name in ((.04,'centelha'),(.30,'risco'),(.65,'aneis'),(.94,'portal'),
                            (1.12,'feixe'),(1.30,'materializacao'),(1.6,'queda')):
                if sim_time>=at and name not in selected and speed==1:
                    pygame.image.save(game.screen,str(out/('panela_'+name+'.png')))
                    selected.add(name)
            if speed==1 and impact_seen and 'impacto' not in selected:
                pygame.image.save(game.screen,str(out/'panela_impacto.png'))
                selected.add('impacto')
            if speed==1 and m.drop.beam_fade>0 and m.drop.impact_age>.15 and 'dissolucao' not in selected:
                pygame.image.save(game.screen,str(out/'panela_dissolucao.png'))
                selected.add('dissolucao')
        counts['panela_'+label]=n
        measurements[label]=dict(render_frames=n,simulation_seconds=round(sim_time,4),
            mean_work_ms=round(statistics.mean(work),3),
            p95_work_ms=round(sorted(work)[int(len(work)*.95)],3),
            delivery_states=sorted(delivery_states))
        print('panela',label,measurements[label],flush=True)

    # Folhas de contato permitem conferir a sequência sem depender de vídeo.
    for kind,size in (('corrida',(320,200)),('panela',(200,250))):
        total=counts[kind+'_normal']
        sheet=pygame.Surface((size[0]*4,size[1]*2)).convert()
        for j in range(8):
            index=round(j*(total-1)/7)
            raw=pygame.image.load(str(out/(kind+'_normal')/f'{index:04}.png'))
            sheet.blit(pygame.transform.smoothscale(raw,size),((j%4)*size[0],(j//4)*size[1]))
        pygame.image.save(sheet,str(out/(kind+'_sequencia.png')))
    report=dict(physics_hz=120,render_sampling_hz=60,audio=False,driver=pygame.display.get_driver(),
                states=states,sequences=counts,measurements=measurements,
                perceptual_review='Sequências e capturas; sem avaliação humana interativa ou audição.')
    # Sessão curta com o limitador e apresentação, fora da escrita dos PNGs.
    game.start_match();game.scene.flow.phase='fight'
    start=perf_counter();real_frames=120
    for i in range(real_frames):
        elapsed=min(game.clock.tick_busy_loop(60)/1000,.1)
        game.development.frame_ms=elapsed*1000
        game.advance(elapsed)
        if i==60:game.scene.trigger_delivery()
        game.scene.draw(game.screen)
        game.development.draw(game.screen,game.clock.get_fps())
        game.viewport.present(game.screen,game.window);pygame.display.flip()
    duration=perf_counter()-start
    report['paced_session']=dict(frames=real_frames,seconds=round(duration,3),fps=round(real_frames/duration,2))
    pygame.image.save(game.screen,str(out/'desenvolvimento.png'))
    print('sessao limitada',report['paced_session'],flush=True)
    (out/'validacao.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    html='''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>ARMS RACE — revisão dos assets</title>
<style>body{background:#070d1e;color:#e5f9ff;font:17px system-ui;margin:24px}button{padding:10px;margin:6px}main{display:flex;gap:16px;flex-wrap:wrap}article{flex:1;min-width:360px}img{max-width:100%;height:auto;background:#101a30}p{max-width:1000px}a{color:#60deff}</style>
<h1>ARMS RACE · revisão visual</h1><p>Render interpolado de peças individuais. Esquerda: 100%. Direita: 25%, com quatro vezes mais quadros para a mesma duração de simulação. Ambas as sequências foram capturadas a 60 quadros por segundo de reprodução.</p>
<button onclick="select('corrida')">Corrida</button><button onclick="select('panela')">Entrega da panela</button><button onclick="toggle()">Pausar / continuar</button><button onclick="step()">Avançar um quadro</button>
<main><article><h2>100%</h2><img id="normal"></article><article><h2>25%</h2><img id="slow"></article></main>
<p id="status"></p><p><a href="personagem_montado.png">Montagem ampliada</a> · <a href="personagem_ossos.png">Ossos e pivôs</a> · <a href="corrida_sequencia.png">Sequência da corrida</a> · <a href="panela_sequencia.png">Sequência da entrega</a> · <a href="assets.json">Auditoria dos PNGs</a> · <a href="validacao.json">Medições</a></p>
<p>Capturas programadas em SDL dummy, sem áudio. Esta prévia permite revisar os quadros, mas não comprova a sensação de suavidade em uma sessão interativa.</p>
<script>const counts=COUNTS,normal=document.getElementById('normal'),slow=document.getElementById('slow'),label=document.getElementById('status');let kind='corrida',playing=true,age=0,last=performance.now();function select(v){kind=v;age=0;paint()}function toggle(){playing=!playing}function step(){playing=false;age+=1/60;paint()}function paint(){let a=Math.floor(age*60)%counts[kind+'_normal'],b=Math.floor(age*60)%counts[kind+'_25'];normal.src=`${kind}_normal/${String(a).padStart(4,'0')}.png`;slow.src=`${kind}_25/${String(b).padStart(4,'0')}.png`;label.textContent=`Quadros: ${a+1} / ${b+1}`;}function tick(now){let dt=(now-last)/1000;last=now;if(playing){age+=Math.min(dt,.1);paint()}requestAnimationFrame(tick)}paint();requestAnimationFrame(tick);</script></html>'''.replace('COUNTS',json.dumps(counts))
    (out/'preview.html').write_text(html,encoding='utf-8')
    game.audio.stop();pygame.quit()


if __name__=='__main__':main()

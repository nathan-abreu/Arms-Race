# Correção visual dos lutadores

Entrega de 03/11/2026. README e fontes de desenho, poses, física, contato,
arma e coordenação da partida foram lidos. Não foi encontrado AGENTS.md no
projeto ou em seus diretórios ancestrais. Os 122 testes existentes passaram
antes das alterações. O workspace já continha alterações de entregas anteriores;
elas foram preservadas. Nenhum commit ou push foi feito.

## Rota efetiva e correção

Antes: `Player.use_sprite_assets=True` selecionava `SpriteFighterArt` em
`Fighter.make_art()`. A CPU selecionava `FighterArt`. O rig PNG usava sockets
e escala próprios das peças musculosas, enquanto a CPU desenhava polígonos.

Agora os dois usam o `FighterArt` existente. As folhas PNG, recortes, manifestos
e `sprite_rig.py` permanecem intactos. O rig arquivado continua coberto pelos
testes que o instanciam explicitamente. Não foi criado outro renderizador.

A guarda tem quadril a 68 px do apoio, tronco de 44 px e cabeça quadrada de
34 px. Cada segmento do braço mede 40 px; cada segmento da perna mede 36 px.
Os alvos de mãos e pés são misturados e as articulações são resolvidas novamente
por IK após cada mistura, incluindo os quadros entre passos da física. Isso
evita mudar comprimentos ou abrir cotovelos/joelhos. A guarda tem joelhos
ligeiramente flexionados; o pouso tem compressão transitória de até 6 px.

O segundo soco usa o ombro traseiro deslocado junto com a preparação do corpo,
preservando a trajetória original da colisão. A Panela usa o socket interpolado
da mão. Sua imagem é desenhada na escala final, sem ampliar o pequeno cache
para o buffer de amostragem. Polígonos do corpo são gerados diretamente em
3× e reduzidos com `smoothscale`; brilho e contorno são discretos.

Arquivos de produção alterados nesta correção: `player.py`, `fighter.py`,
`fighter_art.py`, `poses.py` e `ringue_neon.py`. Na cena, só mudaram a cor do
lutador vermelho e o snapshot das articulações para manter a pose no hit-stop.
Fases, cenário, interface, controles, inventário, áudio, regras e entrega de
armas não foram alterados nesta etapa.

## Evidências e validação

As capturas incluem os dois lutadores no quadro completo de 1280×720, com
a câmera da partida. Não houve ampliação dos personagens para a apresentação:

- [Guarda](../.local/fighter_style/guarda.png)
- [Corrida](../.local/fighter_style/corrida.png)
- [Salto](../.local/fighter_style/salto.png)
- [Ataque com soco](../.local/fighter_style/ataque.png)
- [Ataque com Panela](../.local/fighter_style/panela.png)
- [Driver, estados e coordenadas das articulações](../.local/fighter_style/validacao.json)

Inspeção visual: as cinco imagens foram abertas. Comparadas com a referência
anexada, apresentam cabeça quadrada sem volume, tronco único, membros de
espessura uniforme, mãos menores que a cabeça, pés separados e a mesma
construção para ciano/vermelho. A guarda mantém altura e espaço entre quadril
e piso. Corrida, salto e ataque mantêm segmentos conectados; a Panela encosta
na mão. As bordas diagonais têm antialias e o brilho não encobre a silhueta.
A guarda também foi inspecionada na janela nativa do Windows em 1280×720.

Os quadros usam entradas preparadas sobre a física e o desenho reais, sem
ataques automáticos da CPU. São evidências de poses e bordas estáticas.
Não houve avaliação humana contínua do movimento, audição ou comprovação
de fluidez interativa. Não foi feita medição nova de desempenho.

Comandos executados, todos aprovados:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
# Antes: 122 testes; depois: 128 testes.
.\.venv\Scripts\python.exe -m compileall -q main.py scripts tests tools
.\.venv\Scripts\python.exe main.py --headless --no-audio --scene ringue --frames 120
.\.venv\Scripts\python.exe -m tools.validate_fighter_style --window
```

Os seis testes novos verificam seleção real do renderizador sem carregar
armadura, simetria e altura da guarda, comprimentos em movimento e interpolação,
trajetória dos três socos/Panela em ambas as direções, socket da arma e alpha
nas bordas, apoio dos pés em mira vertical e estabilidade durante hit-stop.
Os testes anteriores de combate, inventário, áudio, cenário e entrega seguem
aprovados. Os testes do rig arquivado preservam a cobertura dos PNGs originais.

Para regenerar os PNGs sem janela, omita `--window`. Na janela de validação,
1–5 selecionam guarda/corrida/salto/soco/Panela e Esc fecha; são atalhos da
ferramenta, sem alterações nos controles do jogo.

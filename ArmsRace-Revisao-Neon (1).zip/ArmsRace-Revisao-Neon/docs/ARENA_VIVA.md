# Arena viva sobre a imagem v2

A arte `assets/imagens/ringue_neon_background_v2.png` é preservada. Os recortes
usam pixels da própria imagem; os overlays acrescentam somente movimento,
iluminação e reação. O piso físico permanece alinhado à plataforma.

## Composição

| Camada | Comportamento |
| --- | --- |
| Fundo distante | Exposição mínima em três variantes prontas e cones ciano, azul e magenta com pivô nas luminárias |
| Arquibancada | Dois recortes mascarados; bastões com fase, velocidade e altura próprias; flashes esparsos |
| Telões | Máscaras na perspectiva da arte, brilho pulsante, scanlines e interferências curtas; troféu com pulso próprio |
| Ringue | Luz nas cordas existentes, vibração localizada, brilho que percorre cordas e plataforma e reflexos de luz no piso |
| Efeitos | Poeira, faíscas discretas, névoa azul e luzes ciano/rosa acompanhando os lutadores |
| Personagens | Sombras com tamanho/opacidade conforme a altura; reflexos comprimidos da pose, recortados no piso |
| Primeiro plano | Recorte da plateia original com deslocamento contrário ao fundo e exposição coerente |
| HUD | Desenhado após a câmera e os efeitos do mundo |

O parallax suaviza a posição média dos lutadores e usa coeficientes diferentes
por camada. As amplitudes ficam em poucos pixels. Piso, personagens e HUD não
recebem esses deslocamentos; a câmera geral continua com seu enquadramento
independente.

## Reações

- Acerto comum: flash difuso breve e destaque no telão do alvo.
- Segundo/terceiro golpe do combo: reação mais longa da plateia e dos telões.
- Golpe forte/Panela: cones intensificados, cordas iluminadas e câmera de impacto.
- Toque nas cordas ou impacto próximo: vibração amortecida em torno do contato.
- Aviso/queda da Panela: iluminação reduzida, cones secundários recuam e o
  feixe dourado existente permanece em destaque.
- Coleta: torcida e telões reagem.
- Vida até 28: telão correspondente pulsa mais rápido e recebe tonalidade
  tensa; iluminação da arena escurece suavemente. O sistema de música
  existente ativa a camada intensa pelo mesmo limiar.
- Nocaute: flash, onda luminosa, câmera de impacto e encerramento já existente
  com 55 ms de pausa e 400 ms de recuperação gradual da câmera lenta.
- Vitória de qualquer lutador: holofote no vencedor, torcida sustentada
  e confetes.

O relógio da arena continua durante hit-stop e encerramento, mas a pausa
interrompe a simulação. As reações têm envelopes separados: o flash termina
antes da torcida e do brilho dos telões. Reiniciar limpa os eventos e mantém
os recursos gráficos em cache.

## Qualidade e orçamento

Em **Esc → Configurações → Visual / partículas**:

| Nível | Holofotes | Bastões | Poeira | Reflexos | Partículas de combate |
| --- | ---: | ---: | ---: | --- | ---: |
| Baixo | 2 | 22 | 6 | Desligados | Até 65 |
| Médio (padrão) | 4 | 62 | 20 | Discretos | Até 125 |
| Alto | 6 | 112 | 40 | Completos | Até 180 |

`Animação da arena: Desligada` congela os overlays ambientais e desliga os
reflexos dos lutadores. Feedback essencial da luta e HUD continuam ativos.
O controle de tremor existente permite zerar o shake independentemente.

Cones têm 33 orientações pré-calculadas por cor. Máscaras, vinheta,
gradientes, variantes de exposição, sombras e buffers de composição persistem.
O desenho não cria superfícies novas para a arena ou o reflexo. A transparência
usa o compositor SDL2; o overlay principal só limpa e copia sua região útil.
Luzes ambientais e plateia são recompostas a 30 Hz em um buffer persistente;
simulação, personagens, reflexos, luzes que acompanham lutadores e HUD seguem
a taxa normal do jogo. Impactos e mudanças de vida invalidam o buffer
imediatamente, sem aguardar a próxima atualização ambiental.
Há no máximo seis vibrações simultâneas de corda, que expiram em 650 ms.
As listas ambientais são fixas e os efeitos de combate respeitam o nível.

## Validação reproduzível

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests
.\.venv\Scripts\python.exe -m compileall -q main.py scripts tests tools
.\.venv\Scripts\python.exe -m tools.validate_living_arena --frames 900 --paced-seconds 30
.\.venv\Scripts\python.exe main.py --headless --no-audio --scene ringue --frames 120
```

108 testes aprovados: os 95 anteriores e 13 novos. A cobertura adicional
verifica movimento em repouso nos três níveis, desligamento, máscaras,
reação por alvo/vida, combo real, coleta, nocaute, reinício, parallax independente,
reflexos recortados, limites de cordas, invalidação imediata do cache nos
impactos e desenho sem novas superfícies.

Capturas e medições ficam em `.local/living_arena/`, ignorado pelo Git:
`preview.html` alterna oito capturas em repouso a cada 500 ms; essa amostragem
serve para conferir movimento e não representa a taxa de atualização do jogo.
O benchmark mede 900 quadros após 60 de aquecimento em cada nível, incluindo
simulação, personagens, HUD e apresentação. A sessão limitada mede FPS real
durante 30 segundos no Alto. Áudio fica desativado em toda a ferramenta.

As capturas de repouso, combo, queda da Panela, nocaute e configurações foram
inspecionadas. As medições usam SDL dummy, 1280×720 e Pygame 2.6.1; não
substituem teste interativo de fluidez ou audição em uma janela real.

Medição de 20/10/2026:

| Nível | Trabalho médio por quadro | Percentil 95 |
| --- | ---: | ---: |
| Baixo | 8,890 ms | 18,400 ms |
| Médio | 11,928 ms | 24,285 ms |
| Alto | 10,050 ms | 18,857 ms |

A sessão com limitador no Alto entregou **1.795 quadros em 30,00 s:
59,83 FPS**, com trabalho médio de 10,539 ms e percentil 95 de 20,994 ms.
Os percentis mostram que ainda ocorrem quadros acima de 16,67 ms; não há
garantia de 60 FPS constantes em todo hardware. Os níveis foram medidos
sequencialmente, sujeitos à carga do sistema e a estados distintos da luta;
isso explica o Médio ter custado mais que o Alto nessa amostra. São tempos
de trabalho, sem a espera do limitador, não FPS exibidos sem limite.

## Arquivos

- `scripts/effects/image_arena.py`: composição, máscaras, caches e envelopes.
- `scripts/effects/feedback.py`: identificação dos eventos da luta.
- `scripts/entities/fighter_art.py`: sombras e reflexos da pose.
- `scripts/scenes/ringue_neon.py`: integração, qualidade e reinício.
- `scripts/settings.py`, `scripts/scenes/options.py`: opção de desligamento.
- `tests/test_living_arena.py`: regressões novas.
- `tools/validate_living_arena.py`: capturas, prévia local e benchmark.

Sem dependências adicionais, edição da imagem-base, commit ou push.

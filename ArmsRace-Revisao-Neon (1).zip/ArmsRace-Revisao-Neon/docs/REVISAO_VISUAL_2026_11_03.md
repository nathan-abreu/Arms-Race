# Revisão visual — 03/11/2026

Esta é uma cópia de trabalho do ZIP recebido. Nenhum commit ou push foi feito.
A versão recebida ainda tinha o portal ornamentado; o último print do usuário já
mostrava outra entrega. Compare esta cópia separadamente antes de integrar alterações
que possam ter sido feitas no computador depois do envio.

## Diagnóstico e correções

- A guarda estreita foi substituída por uma base de 77 px entre os alvos dos pés,
  quadril a 58 px do solo e maior inclinação do tronco. A corrida conserva seu
  ciclo por distância. Os ossos permanecem com comprimentos constantes.
- A panela já tinha uma imagem original detalhada. O desenho era reduzido para
  76 px de largura antes de girar. Agora a rotação parte de uma base de 276 px,
  reduzida no final para aproximadamente 92 px, mantendo o pivô do bojo.
- A entrega troca o portal ornamentado por filamentos dourados, halo translúcido,
  partículas e marcador segmentado de aproximadamente 120 px de largura.
- A rotação durante a queda do céu passa de 420 para -45 graus/s para manter
  a silhueta legível. O descarte continua a 420 graus/s. A colisão de queda
  continua usando o suporte rotacionado existente.
- Os rastros de soco e panela são faixas afiladas na trajetória existente,
  separadas da superfície do corpo. Nenhum machado funcional foi acrescentado.
- Partículas usam transparência progressiva em vez de escurecerem opacas.
  Pouso e passos usam poeira discreta; emissão contínua no ar removida.
- Corrigido corte da metade inferior do marcador pelo buffer do efeito.

## Verificação real

Antes: 128 testes aprovados. Depois: 131 testes aprovados (14,119 s na execução
registrada). Os testes antigos de posição da guarda e amostragem do feixe foram
ajustados às novas proporções; testes de conectividade, comprimentos, colisão,
contato, coleta, entrada e física foram preservados. Três testes novos verificam
fading, ausência de corte no marcador e separação entre rastro e máscara corporal.

Comando: `python -m unittest discover -s tests -v`.

Capturas em `revisao_visual/`: 00 antes, 01 guarda, 02 entrega e 03 contato.
`demonstracao.mp4`: 15 segundos, 1280×720, 60 quadros/s, sem áudio,
renderizados offline pela partida real com entradas programadas. Há reinícios
entre os cinco trechos. A taxa do arquivo não é uma medição de desempenho.
Foram inspecionadas capturas e sequências de quadros. Não houve teste humano
interativo, audição nem medição no computador do usuário.

Reproduzir capturas: `python -m tools.capture_revision`.
Gravar vídeo: `python -m tools.capture_revision --video` (requer ffmpeg no PATH).
O jogo não requer ffmpeg.

## Limites

A arena, HUD, sons, regras e controles permanecem os existentes. A campanha,
loja, machado e armas de fogo não foram implementados nesta revisão. Os slots
vazios são inventário vazio real. A arte continua procedural e não reproduz
exatamente a ilustração. Transições e sensação dos controles precisam da avaliação
humana; o vídeo é uma demonstração, não comprovação de diversão ou suavidade.
Os assets originais foram preservados. O GDD não foi alterado e continua no ZIP
original; foi omitido desta cópia de execução para reduzir o download. Instaladores
de Audacity e Voicemod também foram omitidos, pois não fazem parte do jogo.

## Teste de dois minutos

1. Execute `python main.py --scene ringue --dev --no-audio` (CPU desativada).
2. A/D para correr e inverter; Espaço breve e depois segurado para comparar saltos.
3. Aponte o mouse para o inimigo e clique: compare erro e contato.
4. F8 entrega a panela; espere tocar o chão, recolha e ataque. X descarta.
5. Esc pausa. Feche e abra `python main.py` para testar com CPU e áudio.
F5 muda a velocidade; F6 pausa a simulação; F7 avança um passo; F9 reinicia.

## Arquivos alterados

- `README.md`
- `scripts/balance.py`
- `scripts/combat/weapon.py`
- `scripts/effects/delivery.py`
- `scripts/effects/feedback.py`
- `scripts/effects/pan_art.py`
- `scripts/effects/particles.py`
- `scripts/entities/fighter_art.py`
- `scripts/entities/poses.py`
- `tests/test_fighter_style.py`
- `tests/test_premium.py`

Novos: `tests/test_visual_revision.py`, `tools/capture_revision.py`,
este relatório e a pasta de evidências `revisao_visual/`.

# Integração dos assets — primeira entrega visual

Leitura prévia: README, GDD v2 e implementação existente. Não foi encontrado
`AGENTS.md` no projeto nem nas pastas ancestrais. Os **108 testes anteriores
passaram antes das alterações**. O GDD e a estrutura de fases foram preservados.

## Auditoria e recortes

Todos os sete originais possuem RGBA e transparência. A limpeza atingiu
somente preto neutro conectado ao exterior, atravessando pixels transparentes
com flood fill de quatro vizinhos. Não foi aplicada chroma key global.
RGBs foram preservados; apenas o alpha do fundo identificado passou a zero.
Preto fechado e azul escuro são protegidos e têm teste específico.

| PNG | Dimensões | Margens alpha ≥ 16: esquerda/topo/direita/base | Pixels de fundo limpos |
| --- | --- | --- | ---: |
| nucleo | 2172 × 724 | 85 / 99 / 80 / 97 | 1.455 |
| bracos | 1774 × 887 | 86 / 73 / 75 / 67 | 0 |
| pernas | 1774 × 887 | 333 / 26 / 265 / 26 | 0 |
| panela | 1857 × 847 | 21 / 49 / 21 / 80 | 507 |
| feixe | 725 × 2170 | 31 / 0 / 24 / 16 | 47.293 |
| portal | 1983 × 793 | 29 / 64 / 44 / 31 | 31.936 |
| portal_frames | 2172 × 724 | 62 / 218 / 10 / 123 | 6.067 |

Esses números são da primeira limpeza. Reexecutar o preparador sobre imagens
já limpas é seguro e informa zero pixels adicionais. Os originais anteriores
à limpeza ficam em `.local/asset_rig/originais/`; a auditoria JSON e as capturas
quadriculadas ficam em `.local/asset_rig/assets.json` e `transparencia/`.

O preparador encontra quatro componentes principais no núcleo, seis nos braços
e seis nas pernas pelo canal alpha. O limiar serve apenas para identificar
regiões: cada recorte conserva os pixels RGB/alpha e a resolução da folha.
Há margem de 12 pixels, limitada à imagem. Os 16 nomes solicitados estão em
`assets/personagens/jogador/partes/`, acompanhados de `manifest.json` com origem,
retângulo de recorte, limites internos e tamanho. Um teste compara cada recorte
byte a byte com a região correspondente da folha limpa.

Os seis estágios do portal têm larguras diferentes. Seus intervalos calibrados
estão no preparador; os frames separados ficam em `assets/armas/panela/frames/`.

## Rig e renderização

`SpriteFighterArt` conserva a API do renderizador anterior e usa 16 ossos
hierárquicos. Cada osso guarda pai, socket do pai, pivô, posição e ângulos local
e global em float. Quadril → tronco → pescoço → cabeça; braços saem do tronco,
pernas do quadril. Cotovelos, punhos, joelhos e tornozelos herdam exatamente
o ponto de conexão do segmento anterior. IK de dois segmentos mantém os
comprimentos físicos e os encaixes; o desenho interpola ângulos locais e
reavalia a hierarquia para não abrir as articulações entre passos.

Os PNGs são carregados uma vez. Cada peça tem escala uniforme de 0,09 no mundo,
com preparação e composição em **2×** a resolução final. `rotozoom` gira as
peças e `smoothscale` reduz o buffer persistente de 600×540 para 300×270.
O zoom da câmera também passou a usar `smoothscale`. Não há frames completos
do personagem nem troca de sprites de corpo inteiro. A CPU conserva a arte
anterior, pois não foi fornecido um conjunto de PNGs para ela.

Guarda com respiração, início de corrida, corrida, frenagem, preparação do
salto, subida, ápice, queda e pouso são poses procedurais. Transições guardam
a pose corrente e fazem mistura suave de **100 ms**. A corrida tem ciclo de
72 pixels de distância percorrida, com 36 pixels de apoio por perna; o avanço
vem do deslocamento físico real, não do tempo de renderização. A física pula
imediatamente; a preparação visual acompanha os primeiros 45 ms da subida.

## Física e controles

O loop real usa `FIXED_DT = 1/120`, acumulador e render interpolado. Posições
anteriores/atuais do jogador, CPU e Panela são separadas. A orientação da
Panela usa o arco angular mais curto na interpolação. O estado visual do portal
também interpola cronômetros, alpha e dissolução entre passos.

A/D, Espaço, mouse e clique esquerdo são preservados. Aceleração, frenagem,
inversão, controle aéreo, salto variável, coyote/buffer de 120 ms e gravidade
maior na queda continuam no controlador existente. O pouso comprime a pose
com mistura suave, sem redimensionar as peças.

## Entrega da Panela

Usa `panela.png` no mundo, na mão, na coleta e no inventário. O pivô permanece
no centro do bojo; o interior escuro vem do PNG e não é removido.

1. Centelha com alpha crescente e risco dourado.
2. Anéis e seis estágios de `portal_frames.png`, misturados por alpha.
3. Abertura com `portal.png`, escala/rotação suaves e feixe revelado de cima
   para baixo a partir de `feixe.png`.
4. Materialização com alpha e escala uniformes durante o fim da abertura.
5. Queda acelerada e rotação, com detecção varrida de dano.
6. Contato com suporte do bojo/cabo, resolvido dentro do passo por busca da
   fração do impacto; flash, partículas, áudio e tremor existentes são acionados.
7. Acomodação angular contínua e dissolução de portal/feixe por 350 ms.

O aviso dura 900 ms, a abertura 420 ms e a origem fica em y=132, abaixo do HUD.
A aceleração da entrega é 1.850 px/s². O feixe alinha o círculo de contato do
PNG ao piso e conserva a altura ao dissolver, reduzindo somente o alpha.
Partículas usam coordenadas float e relógio de simulação. A coleta guarda o
ângulo inicial para não trocar subitamente a orientação do objeto.

## Revisão no desenvolvimento

```powershell
.\.venv\Scripts\python.exe main.py --scene ringue --dev --no-audio
```

| Tecla | Ação em `--dev` |
| --- | --- |
| F5 | 100% → 50% → 25% |
| F6 | Pausar/retomar a simulação |
| F7 | Um passo exato de 1/120 s, mantendo pausa |
| F8 | Acionar entrega, mantendo uma única Panela |
| F9 | Reiniciar rapidamente a partida |
| F10 | Ossos e pivôs sobre o render interpolado |

O painel mostra velocidade, pausa, FPS e tempo de quadro. A CPU fica parada
nesse modo para permitir revisão visual. Fora dele, o combate e a CPU seguem
ativos. Não foram adicionadas fases nem um novo sistema de combate.

## Validação e evidências

```powershell
.\.venv\Scripts\python.exe -m tools.prepare_assets
.\.venv\Scripts\python.exe -m unittest discover -s tests
.\.venv\Scripts\python.exe -m compileall -q main.py scripts tests tools
.\.venv\Scripts\python.exe -m tools.validate_asset_rig
.\.venv\Scripts\python.exe main.py --headless --no-audio --dev --scene ringue --frames 120
```

Os testes históricos mantêm passos grossos de 60 Hz em `tests/support.py`
para conservar seus tempos de referência e verificar tolerância do motor.
A bateria nova exercita o relógio real de 120 Hz, incluindo apresentação
a 30, 60 e 144 FPS, velocidade de 25%, passo único, conservação da pose,
conexões das peças, transparência, crescimento/dissolução e contato da Panela.
As expectativas antigas de cor plana, origem acima da tela e tempos de
abertura/dissolução foram atualizadas para os PNGs e a nova entrega.

Resultado final: **122 testes aprovados** (108 históricos e 14 novos),
sintaxe verificada e inicialização de 120 quadros com `--headless --no-audio --dev`.

Medição de apoio em corrida estabilizada: **108 pares de amostras**, com
deslocamento máximo do pé apoiado de **0 px nas coordenadas físicas**. Isso
não é uma afirmação de ausência perceptual de tremedeira no monitor.

Evidências em `.local/asset_rig/`:

- `preview.html`: comparação reproduzível 100%/25%, pausa e avanço de quadro.
- `personagem_montado.png`, `personagem_alpha.png`, `personagem_ossos.png`.
- `estado_*.png`: os nove estados de movimento.
- `corrida_normal/`: 72 quadros; `corrida_25/`: 288 quadros.
- `panela_normal/`: 156 quadros; `panela_25/`: 624 quadros.
- `corrida_sequencia.png`, `panela_sequencia.png`: folhas de contato.
- `panela_*.png`: etapas da entrega; `desenvolvimento.png`: painel de revisão.
- `validacao.json`: estados percorridos, contagens e custos medidos.

As sequências são produzidas pela simulação a 120 Hz e pelo render interpolado,
amostrado em 60 quadros por segundo de reprodução. A versão 25% tem quatro
vezes mais imagens para a mesma duração simulada; não é apenas um atraso
adicionado ao navegador. A geração é offline e sua taxa de amostragem não
comprova desempenho em tempo real. O JSON separa uma sessão com limitador,
sem escrita de PNGs durante sua medição.

Medição em SDL dummy, 1280×720, sem áudio, em 20/10/2026:

| Captura | Trabalho médio por quadro | Percentil 95 |
| --- | ---: | ---: |
| Entrega 100% | 27,456 ms | 46,595 ms |
| Entrega 25% | 20,810 ms | 40,453 ms |

A sessão com limitador e painel de desenvolvimento registrou **120 quadros
em 6,013 s: 19,96 FPS**. Portanto, esta revisão não comprova 60 FPS neste
ambiente headless. Os custos de captura e essa sessão curta são evidências
locais, sujeitas à carga do sistema; não substituem medição em janela real.
O rig usa buffers persistentes e 2× de resolução para reduzir o custo,
mantendo rotação filtrada e interpolação. O desempenho visual em hardware
real ainda precisa ser avaliado pelo modo de desenvolvimento.

Capturas e folhas de contato foram inspecionadas. Não houve teste humano
interativo nem audição; SDL dummy e verificações numéricas não comprovam
suavidade perceptual. O modo `--dev` permite essa revisão no computador real.

Sem dependências adicionais, commit ou push.

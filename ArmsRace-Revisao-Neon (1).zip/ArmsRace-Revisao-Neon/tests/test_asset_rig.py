import os
os.environ['SDL_VIDEODRIVER']='dummy'
os.environ['SDL_AUDIODRIVER']='dummy'
import json
import math
import unittest
from collections import defaultdict
from pathlib import Path
from unittest.mock import patch
import pygame
from scripts.config import ROOT,FIXED_DT,PHYSICS_HZ
from scripts.game import Game
from scripts.entities.player import Player
from scripts.entities.sprite_rig import SpriteFighterArt,pieces,SCALE
from scripts.balance import DELIVERY
from scripts.combat.weapon import pan_support
from tools.prepare_assets import border_black,NAMES


class AssetRigTests(unittest.TestCase):
    def setUp(self):
        self.game=Game('ringue',audio_enabled=False,developer=True)
        self.m=self.game.scene;self.m.flow.phase='fight'
        self.f=self.m.player;self.f.animate(1)

    def tearDown(self):
        self.game.audio.stop();pygame.quit()

    def test_sources_alpha_and_exact_unscaled_crops(self):
        folder=ROOT/'assets/personagens/jogador'
        manifest=json.loads((folder/'partes/manifest.json').read_text(encoding='utf-8'))
        self.assertEqual(set(manifest),set(sum((list(n) for n in NAMES.values()),[])))
        for name,data in manifest.items():
            source=pygame.image.load(str(folder/data['sheet'])).convert_alpha()
            crop=pygame.image.load(str(folder/'partes'/(name+'.png'))).convert_alpha()
            self.assertEqual(crop.get_size(),tuple(data['size']))
            self.assertEqual(pygame.image.tobytes(crop,'RGBA'),
                             pygame.image.tobytes(source.subsurface(data['rect']),'RGBA'))
        for folder in (folder,ROOT/'assets/armas/panela'):
            for path in folder.glob('*.png'):
                s=pygame.image.load(str(path))
                self.assertNotEqual(s.get_masks()[3],0,path)
                self.assertGreater(pygame.image.tobytes(s,'RGBA')[3::4].count(0),0)

    def test_flood_fill_preserves_enclosed_black_and_dark_blue(self):
        s=pygame.Surface((9,9),pygame.SRCALPHA);s.fill((0,0,0,255))
        pygame.draw.rect(s,(0,5,8,255),(2,2,5,5),1)
        s.set_at((8,5),(0,0,7,255))  # azul muito escuro conectado à borda
        s.set_at((4,4),(1,1,1,255))
        cleaned,count=border_black(s)
        self.assertGreater(count,0)
        self.assertEqual(cleaned.get_at((0,0)).a,0)
        self.assertEqual(cleaned.get_at((4,4)),s.get_at((4,4)))
        self.assertEqual(cleaned.get_at((2,3)),s.get_at((2,3)))
        self.assertEqual(cleaned.get_at((8,5)),s.get_at((8,5)))

    def test_hierarchy_and_all_sockets_remain_connected(self):
        # O rig PNG permanece arquivado e coberto, fora da rota da partida.
        self.f.use_sprite_assets=True;self.f.art=SpriteFighterArt();self.f.animate(1)
        art=self.f.art
        self.assertIsInstance(art,SpriteFighterArt)
        for state in ('parado','iniciando_corrida','correndo','freando','preparando_salto',
                      'pulando','apice','caindo','pousando'):
            self.f.movement_state=state
            self.f.velocity.update(380 if 'corr' in state else 0,-200 if state=='pulando' else 0)
            for _ in range(15):self.f.animate(FIXED_DT)
            self.assertEqual(len(art.bones),16)
            for bone in art.bones.values():
                if bone.parent:
                    expected=art.bones[bone.parent].point(bone.socket)
                    self.assertLess(expected.distance_to(bone.origin),1e-8,state)
                self.assertTrue(math.isfinite(bone.angle))
            self.f.draw(self.game.screen)
            self.assertEqual(len(pygame.mask.from_surface(art.sprite,80).connected_components(60)),1,state)

    def test_transition_snapshot_preserves_current_pose(self):
        self.f.use_sprite_assets=True;self.f.art=SpriteFighterArt();self.f.animate(1)
        art=self.f.art
        for state in ('correndo','freando','pulando','caindo'):
            before={n:(b.origin.copy(),b.angle) for n,b in art.bones.items()}
            self.f.movement_state=state
            self.f.animate(0)
            for n,b in art.bones.items():
                self.assertLess(b.origin.distance_to(before[n][0]),1e-7)
                self.assertAlmostEqual(b.angle,before[n][1],places=7)
            self.f.animate(.05)

    def test_planted_feet_do_not_slide_at_constant_speed(self):
        f=self.f;f.axis=1;floor=[pygame.Rect(-1000,514,5000,30)]
        for _ in range(50):f.update(FIXED_DT,floor)
        previous={};max_error=0;checked=0
        for _ in range(120):
            f.update(FIXED_DT,floor)
            for suffix,offset in (('l',0),('r',52)):
                phase=(f.stride_distance+offset)%104
                point=f.pos+f.art.points['foot_'+suffix]+(0,4)
                if suffix in previous and phase<52 and previous[suffix][0]<phase:
                    max_error=max(max_error,point.distance_to(previous[suffix][1]));checked+=1
                previous[suffix]=(phase,point)
        self.assertGreater(checked,80)
        self.assertLess(max_error,.15)

    def test_same_physics_at_30_60_and_144_render_fps(self):
        self.assertEqual(PHYSICS_HZ,120);self.assertEqual(FIXED_DT,1/120)
        results=[]
        for fps in (30,60,144):
            self.game.start_match();m=self.game.scene;m.flow.phase='fight'
            keys=defaultdict(bool);keys[pygame.K_d]=True
            calls=[]
            def step(dt):
                calls.append(dt);m.simulate(dt,keys)
            self.game.accumulator=0
            with patch.object(m,'update',side_effect=step):
                for _ in range(fps):self.game.advance(1/fps)
            self.assertEqual(len(calls),120)
            self.assertTrue(all(dt==1/120 for dt in calls))
            results.append((m.player.pos.copy(),m.player.stride_distance))
        for position,stride in results[1:]:
            self.assertLess(position.distance_to(results[0][0]),1e-7)
            self.assertAlmostEqual(stride,results[0][1])

    def test_quarter_speed_and_exact_single_step(self):
        dev=self.game.development
        dev.speed=.25
        with patch.object(self.m,'update') as update:
            for _ in range(60):self.game.advance(1/60)
            self.assertEqual(update.call_count,30)
            dev.paused=True
            self.game.advance(.1);self.assertEqual(update.call_count,30)
            dev.step_requested=True
            self.game.advance(.1);self.assertEqual(update.call_count,31)
            self.game.advance(.1);self.assertEqual(update.call_count,31)

    def test_interpolated_position_is_between_physics_snapshots(self):
        self.f.axis=1;self.f.update(FIXED_DT,self.m.platforms)
        with patch.object(self.f.art,'draw') as draw:
            self.f.draw(self.game.screen,.25)
            point=draw.call_args[0][3]
            self.assertLess(point.distance_to(self.f.previous_pos.lerp(self.f.pos,.25)),1e-9)

    def test_jump_controls_coyote_buffer_and_variable_height(self):
        self.assertTrue(self.f.request_jump())
        self.assertLess(self.f.velocity.y,0)
        self.f.release_jump();self.assertEqual(self.f.velocity.y,-270)
        other=Player((400,200));other.coyote_time=.12
        other.update(.11,[]);self.assertTrue(other.request_jump())
        expired=Player((400,200));expired.coyote_time=.12
        expired.update(.121,[]);self.assertFalse(expired.request_jump())
        buffered=Player((400,500));buffered.velocity.y=300
        self.assertFalse(buffered.request_jump())
        for _ in range(8):buffered.update(FIXED_DT,self.m.platforms)
        self.assertLess(buffered.velocity.y,0)

    def test_portal_starts_invisible_and_beam_grows_continuously(self):
        self.m.trigger_delivery();d=self.m.drop
        self.assertEqual(d.state,'warning')
        first=d.art.parameters(d)
        self.assertEqual(first['spark'],0);self.assertEqual(first['portal'],0)
        self.assertEqual(first['beam'],0)
        last=first;stages=set()
        for _ in range(280):
            d.update(FIXED_DT,self.m.fighters,self.m.platforms)
            p=d.art.parameters(d);stages.add(d.state)
            for key in ('spark','portal','beam','material'):
                self.assertLessEqual(abs(p[key]-last[key]),.09,key)
            last=p
        self.assertTrue({'warning','opening','falling','available'}<=stages)

    def test_falling_pan_never_teleports_and_dissolves_after_impact(self):
        self.m.trigger_delivery();d=self.m.drop
        last=None;fall_steps=0;impact=False
        for _ in range(300):
            before=d.state
            d.update(FIXED_DT,self.m.fighters,self.m.platforms)
            if d.state=='falling':
                if last is not None:
                    self.assertGreaterEqual(d.y,last)
                    self.assertLess(d.y-last,12)
                last=d.y;fall_steps+=1
            if d.impact_event:
                impact=True
                self.assertGreater(d.beam_fade,.3)
                self.assertGreater(d.art.parameters(d)['beam'],.95)
                break
        self.assertTrue(impact);self.assertGreater(fall_steps,50)
        d.update(.15,self.m.fighters,self.m.platforms)
        self.assertGreater(d.art.parameters(d)['beam'],0)
        d.update(.25,self.m.fighters,self.m.platforms)
        self.assertEqual(d.beam_fade,0)

    def test_developer_shortcuts_and_unique_manual_pan(self):
        for key in (pygame.K_F5,pygame.K_F5):
            self.game.process_event(pygame.event.Event(pygame.KEYDOWN,key=key))
        self.assertEqual(self.game.development.speed,.25)
        self.game.process_event(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_F8))
        self.assertEqual(self.m.drop.state,'warning')
        self.game.process_event(pygame.event.Event(pygame.KEYDOWN,key=pygame.K_F10))
        self.assertFalse(self.game.development.show_bones)

    def test_rotating_handle_touches_floor_without_position_snap(self):
        self.m.trigger_delivery();d=self.m.drop
        while d.state!='falling':d.update(FIXED_DT,self.m.fighters,self.m.platforms)
        while d.state=='falling':
            previous=d.y
            d.update(FIXED_DT,self.m.fighters,self.m.platforms)
            self.assertGreaterEqual(d.y,previous)
            self.assertLess(d.y-previous,12)
        self.assertAlmostEqual(d.y+pan_support(d.angle),self.m.platforms[0].top,delta=.01)
        for _ in range(30):
            d.update(FIXED_DT,self.m.fighters,self.m.platforms)
            self.assertAlmostEqual(d.y+pan_support(d.angle),self.m.platforms[0].top,delta=.01)
        self.assertAlmostEqual(d.angle,0)

    def test_feet_extend_before_landing_and_contact_the_floor(self):
        f=self.f;f.request_jump()
        for i in range(240):
            if i==12:f.release_jump()
            f.update(FIXED_DT,self.m.platforms)
            if f.grounded:
                for side in ('l','r'):
                    sole=f.pos.y+f.art.points['foot_'+side].y+4
                    self.assertAlmostEqual(sole,self.m.platforms[0].top,delta=.5)
                break
        else:self.fail('O salto não terminou no prazo')


if __name__=='__main__':unittest.main()

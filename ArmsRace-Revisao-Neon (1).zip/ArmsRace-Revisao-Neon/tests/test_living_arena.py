"""Regressões da composição, eventos e orçamento de alocações da arena."""
import os
os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"

import unittest
from unittest.mock import patch
import pygame

from scripts.game import Game
from tests.support import COARSE_DT as FIXED_DT
from scripts.scenes.options import Options


class LivingArenaTests(unittest.TestCase):
    def setUp(self):
        self.game = Game("ringue", audio_enabled=False)
        self.m = self.game.scene
        self.m.flow.phase = "fight"
        self.a = self.m.art
        for f in self.m.fighters:
            f.animate(1)

    def tearDown(self):
        self.game.audio.stop()
        pygame.quit()

    def pixels(self, rect=None):
        self.a.draw(self.game.screen)
        s = self.game.screen.subsurface(rect) if rect else self.game.screen
        return pygame.image.tobytes(s, "RGB")

    def test_idle_animation_in_all_three_presets(self):
        for q in range(3):
            self.game.settings.particles = q
            self.a.configure(self.m.fighters,self.m.drop,self.game.settings)
            before = self.pixels()
            self.a.update(1.2)
            self.assertNotEqual(before,self.pixels(),q)

    def test_environment_cache_does_not_delay_damage_or_follow_light(self):
        self.pixels()
        with patch.object(self.a,"_draw_environment",wraps=self.a._draw_environment) as draw:
            before=self.pixels()
            self.m.player.pos.x+=40
            self.assertNotEqual(before,self.pixels())
            self.assertEqual(draw.call_count,0)
            self.a.react(.22,side=0)
            self.pixels()
            self.assertEqual(draw.call_count,1)
            self.a.update(1/30)
            self.pixels()
            self.assertEqual(draw.call_count,2)

    def test_disable_is_available_in_options_and_freezes_arena(self):
        options = Options(self.game,self.m)
        options.selected = 8
        options.adjust(1)
        self.assertFalse(self.game.settings.arena_effects)
        self.a.configure(self.m.fighters,self.m.drop,self.game.settings)
        before = self.pixels()
        self.a.react(1.4,event="knockout")
        self.a.update(2)
        self.assertEqual(before,self.pixels())
        options.adjust(1)
        self.assertTrue(self.game.settings.arena_effects)

    def test_draw_reuses_surfaces_even_during_events_and_quality_switches(self):
        self.m.draw(self.game.screen)  # aquece fontes e rig
        original = pygame.image.tobytes(self.a.base,"RGB")
        for q in range(3):
            self.game.settings.particles = q
            self.a.configure(self.m.fighters,self.m.drop,self.game.settings)
            self.a.react(1.2,event="combo",position=(150,420))
            with patch("pygame.Surface",side_effect=AssertionError("alocação no frame")):
                for _ in range(3):
                    self.a.update(FIXED_DT)
                    self.a.draw(self.game.screen)
                    for f in self.m.fighters:
                        f.draw(self.game.screen)
                    self.a.draw_foreground(self.game.screen)
        self.assertEqual(original,pygame.image.tobytes(self.a.base,"RGB"))

    def test_damage_flashes_only_corresponding_screen_and_expires(self):
        self.a.react(.22,side=1)
        self.assertEqual(self.a.damage[0],0)
        self.assertGreater(self.a.damage[1],0)
        self.a.update(.23)
        self.assertEqual(self.a.damage,[0,0])

    def test_health_changes_only_its_screen_tint(self):
        self.a._draw_screens(self.game.screen)
        original = [pygame.image.tobytes(fx,"RGBA") for fx in self.a.screen_fx]
        self.m.enemy.health = 15
        self.a._draw_screens(self.game.screen)
        changed = [pygame.image.tobytes(fx,"RGBA") for fx in self.a.screen_fx]
        self.assertEqual(original[0],changed[0])
        self.assertEqual(original[1],changed[1])
        self.assertNotEqual(original[2],changed[2])
        for fx in self.a.screen_fx:
            self.assertEqual(fx.get_at((0,0)).a,0)
            self.assertEqual(fx.get_at((fx.get_width()-1,0)).a,0)

    def test_combo_collect_and_knockout_have_longer_crowd_reaction(self):
        self.a.react(.22)
        self.a.update(.4)
        self.assertEqual(self.a.crowd_energy,0)
        for event in ("combo","collect","knockout"):
            self.a.react(.85,event=event)
            self.a.update(.4)
            self.assertGreater(self.a.crowd_energy,.8,event)
            self.assertEqual(self.a.flash,0)
            self.a.reset()

    def test_ropes_localized_bounded_and_decay(self):
        self.a.react(.3,position=(640,200))
        self.assertEqual(self.a.rope_hits,[])
        for _ in range(100):
            self.a.react(.55,event="rope",position=(150,480))
        self.assertEqual(len(self.a.rope_hits),6)
        self.assertEqual(self.a.rope_hits[0][0],150)
        self.a.update(.66)
        self.assertEqual(self.a.rope_hits,[])
        f=self.m.player
        previous=f.pos.x
        f.pos.x=self.m.platforms[0].left
        self.m._ropes(f,previous)
        self.assertTrue(self.a.rope_hits)

    def test_depths_move_independently_with_static_floor_and_hud(self):
        for f in self.m.fighters:
            f.pos.x += 250
        self.a.update(2)
        offsets = self.a.layer_offsets
        for name in ("ring","fighters","hud"):
            self.assertEqual(offsets[name],(0,0))
        self.assertNotEqual(offsets["crowd"],offsets["foreground"])
        self.assertNotEqual(offsets["distant"],offsets["effects"])
        self.assertTrue(all(abs(x)<=5 and abs(y)<=2 for x,y in offsets.values()))

    def test_drop_darkens_and_critical_health_works_without_audio(self):
        normal = self.pixels((600,90,30,30))
        self.m.drop.state = "falling"
        self.assertNotEqual(normal,self.pixels((600,90,30,30)))
        self.m.player.health = 20
        self.m.simulate(FIXED_DT)
        self.assertTrue(self.a.low_health)
        self.assertFalse(self.game.audio.enabled)

    def test_combat_feedback_drives_combo_and_collection(self):
        f,t = self.m.fighters
        f.pos.x,t.pos.x = 570,657
        f.set_aim(t.shoulder)
        f.attack()
        for _ in range(16):
            f.update(FIXED_DT,self.m.platforms)
        f.attack()
        for _ in range(4):
            f.update(FIXED_DT,self.m.platforms)
        self.assertTrue(f.resolve_attack(t))
        self.m.feedback.hit(self.m,f,t)
        self.assertGreater(self.a.crowd_energy,.9)
        self.assertGreater(self.a.damage[1],0)
        self.a.reset()
        self.m.feedback.collect(self.m,f)
        self.assertGreater(self.a.crowd_energy,1)

    def test_knockout_slow_motion_winner_and_restart_reset(self):
        self.m.enemy.health = 0
        self.m.check_result()
        self.assertEqual(self.m.flow.phase,"finish")
        self.assertTrue(self.m.player.celebrating)
        self.assertGreater(self.a.crowd_energy,2)
        self.assertTrue(any(p[5]=="confetti" for p in self.m.particles.items))
        self.m.simulate(.1)
        self.assertEqual(self.m.flow.phase,"finish")
        self.assertIs(self.a.winner,self.m.player)
        self.game.start_match()
        self.assertIs(self.game.scene.art,self.a)
        self.assertEqual(self.a.crowd_energy,0)
        self.assertIsNone(self.a.winner)
        self.assertEqual(self.a.damage,[0,0])

    def test_reflections_disabled_on_low_and_clipped_to_floor(self):
        f = self.m.player
        f.visual_ground = self.m.platforms[0].top
        floor = f.visual_ground
        f.visual_quality = 0
        self.game.screen.fill((0,0,0))
        f.art.draw_floor(self.game.screen,f)
        low = pygame.image.tobytes(self.game.screen,"RGB")
        self.assertEqual(self.game.screen.get_at((int(f.pos.x),floor+10)).r,0)
        f.visual_quality = 2
        self.game.screen.fill((0,0,0))
        f.art.draw_floor(self.game.screen,f)
        self.assertNotEqual(low,pygame.image.tobytes(self.game.screen,"RGB"))
        self.assertEqual(self.game.screen.get_at((int(f.pos.x),floor+15)).r,0)


if __name__ == "__main__":
    unittest.main()

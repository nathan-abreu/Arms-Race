"""Contratos da apresentação ativa, incluindo quadros entre passos físicos."""
import os
os.environ['SDL_VIDEODRIVER']='dummy'
os.environ['SDL_AUDIODRIVER']='dummy'
import unittest
from unittest.mock import patch
import pygame
from scripts.game import Game
from scripts.config import FIXED_DT
from scripts.entities.fighter_art import FighterArt
from scripts.entities.poses import ARM_LENGTH,LEG_LENGTH
from scripts.combat.weapon import FISTS,PAN


class FighterStyleTests(unittest.TestCase):
    def setUp(self):
        self.game=Game('ringue',audio_enabled=False)
        self.m=self.game.scene;self.m.flow.phase='fight'
        for f in self.m.fighters:f.animate(1)

    def tearDown(self):
        self.game.audio.stop();pygame.quit()

    def assert_lengths(self,p):
        for a,b,length in (('hip','knee_l',LEG_LENGTH),('knee_l','foot_l',LEG_LENGTH),
                           ('hip','knee_r',LEG_LENGTH),('knee_r','foot_r',LEG_LENGTH),
                           ('shoulder','elbow',ARM_LENGTH),('elbow','hand',ARM_LENGTH),
                           ('back_shoulder','back_elbow',ARM_LENGTH),('back_elbow','back_hand',ARM_LENGTH)):
            self.assertAlmostEqual(p[a].distance_to(p[b]),length,places=6,msg=(a,b))

    def test_match_uses_same_flat_renderer_without_loading_armour(self):
        with patch('scripts.entities.sprite_rig.pieces',side_effect=AssertionError('Armadura na rota ativa')):
            self.game.start_match()
            for f in self.game.scene.fighters:
                f.animate(1);f.draw(self.game.screen)
                self.assertIs(type(f.art),FighterArt)
        self.assertLess(self.m.player.color[0],30)
        self.assertLess(self.m.enemy.color[2],60)

    def test_mirrored_guard_has_same_proportions_and_wide_grounded_stance(self):
        a,b=self.m.fighters
        a.set_aim(a.shoulder+(200,0));b.set_aim(b.shoulder+(-200,0))
        for f in (a,b):f.art=None;f.animate(1)
        for key,v in a.art.points.items():
            other=b.art.points[key]
            self.assertAlmostEqual(v.x,-other.x)
            self.assertAlmostEqual(v.y,other.y)
        for f in (a,b):
            p=f.art.points;self.assert_lengths(p)
            self.assertLess(p['hip'].y,-55)
            self.assertGreater(abs(p['foot_l'].x-p['foot_r'].x),70)
            self.assertLess(p['head'].y,-120)
            for side in ('l','r'):
                self.assertGreater(p['hip'].distance_to(p['foot_'+side]),LEG_LENGTH*1.7)
                self.assertEqual(p['foot_'+side].y+4,0)

    def test_lengths_remain_constant_through_movement_and_render_interpolation(self):
        for f in self.m.fighters:
            for state in ('correndo','freando','pulando','apice','caindo','pousando','parado'):
                f.movement_state=state;f.grounded=state not in ('pulando','apice','caindo')
                f.velocity.update(300 if state=='correndo' else 0,-250 if state=='pulando' else 0)
                for i in range(12):
                    f.stride_distance+=3.1;f.animation_time+=FIXED_DT
                    f.animate(FIXED_DT);self.assert_lengths(f.art.points)
                    for alpha in (0,.25,.5,.75,1):
                        f.draw(self.game.screen,alpha)
                        self.assert_lengths(f.art.rendered_points)

    def test_combo_and_pan_keep_lengths_and_track_existing_collision_path(self):
        f=self.m.player
        for direction in (-1,1):
            for angle in (-85,-40,0,40,85):
                for weapon,combo in ((FISTS,1),(FISTS,2),(FISTS,3),(PAN,0)):
                    f.inventory.slots=[weapon if weapon is PAN else None,None,None]
                    f.cooldown=f.recovery=f.stun=0;f.combo_left=1;f.combo_index=combo-1
                    f.set_aim(f.shoulder+pygame.Vector2(direction*200,0).rotate(angle))
                    f.attack()
                    for _ in range(15):
                        f.tick_attack(FIXED_DT);f.animate(FIXED_DT)
                        self.assert_lengths(f.art.points)
                        if f.attack_time>0 and f.windup<=0:
                            key='back_hand' if f.punch_arm==1 else 'hand'
                            _,end=f.attack_segment()
                            actual=f.pos+f.art.points[key]
                            if weapon is PAN:actual+=f.swing_vector()*22
                            self.assertLess(actual.distance_to(end),.0001,
                                            (direction,angle,weapon.name,combo,f.art.points))

    def test_pan_draw_uses_interpolated_hand_socket_and_filtered_edges(self):
        f=self.m.player;f.inventory.collect(PAN);f.set_aim(f.shoulder+(200,-60))
        f.animate(.03)
        with patch('scripts.entities.fighter_art.pan') as draw_pan:
            f.draw(self.game.screen,.3)
        expected=f.art.rendered_points['hand']+(150,218)+f.aim*22
        self.assertLess(draw_pan.call_args[0][1].distance_to(expected),1e-7)
        alpha=pygame.image.tobytes(f.art.sprite,'RGBA')[3::4]
        self.assertTrue(any(0<a<255 for a in alpha))
        self.assertEqual(len(pygame.mask.from_surface(f.art.sprite,80).connected_components(40)),1)

    def test_downward_guard_keeps_both_soles_grounded_and_hitstop_holds_pose(self):
        for f in self.m.fighters:
            for angle in range(-180,181,15):
                f.set_aim(f.shoulder+pygame.Vector2(200,0).rotate(angle))
                f.art=None;f.animate(1)
                for side in ('l','r'):
                    self.assertAlmostEqual(f.art.points['foot_'+side].y+4,0,places=6)
        self.m.hit_stop=.08
        self.m.simulate(FIXED_DT)
        f=self.m.player
        samples=[]
        for alpha in (0,.5,1):
            f.draw(self.game.screen,alpha)
            samples.append(f.art.rendered_points['hand'].copy())
        self.assertLess(samples[0].distance_to(samples[-1]),1e-8)


if __name__=='__main__':unittest.main()

"""Passo grosso preservado nos testes históricos de duração e tolerância.

O loop real usa 120 Hz; test_asset_rig cobre esse relógio e sua interpolação.
Estes testes também exercitam compatibilidade do motor com passos de 60 Hz.
"""
COARSE_DT=1/60

"""Regressões visuais: fading e efeitos separados do corpo físico."""
import os
os.environ['SDL_VIDEODRIVER']='dummy'
os.environ['SDL_AUDIODRIVER']='dummy'
import unittest
import pygame
from scripts.effects.particles import Particles
from scripts.game import Game

class VisualRevisionTests(unittest.TestCase):
    def setUp(self):
        pygame.init();pygame.display.set_mode((1280,720))
    def tearDown(self):pygame.quit()
    def test_particle_fades_to_background_instead_of_black(self):
        p=Particles();s=pygame.Surface((1280,720));values=[]
        for remaining in (1,.5,.1):
            p.items=[[pygame.Vector2(200,200),pygame.Vector2(100,0),remaining,1,(0,240,255),'spark']]
            s.fill((30,35,40));p.draw(s)
            pixel=s.get_at((200,200));values.append(pixel.b)
            self.assertGreaterEqual(pixel.b,40)
        self.assertGreater(values[0],values[1]);self.assertGreater(values[1],values[2])
        p.update(.2);self.assertFalse(p.items)
    def test_marker_bottom_is_not_clipped_by_effect_buffer(self):
        g=Game('ringue',audio_enabled=False,developer=True);m=g.scene
        m.trigger_delivery();d=m.drop
        d.state='falling';d.timer=0;d.effect_age=1.5
        s=pygame.Surface((1280,720),pygame.SRCALPHA)
        d.art.draw(s,d,0)
        self.assertTrue(any(d.art.lines.get_at((x,d.floor_y+3)).a>0 for x in range(40,180)))
        g.audio.stop()
    def test_miss_trail_is_visible_but_does_not_split_body_mask(self):
        g=Game('ringue',audio_enabled=False);f=g.scene.player
        f.attack();f.tick_attack(.08);f.animate(.08);f.draw(g.screen)
        self.assertGreater(pygame.mask.from_surface(f.art.trail,10).count(),0)
        self.assertEqual(len(pygame.mask.from_surface(f.art.sprite,80).connected_components(40)),1)
        self.assertEqual(g.scene.enemy.health,100)
        g.audio.stop()
